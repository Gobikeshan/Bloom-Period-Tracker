package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BloomRepository
import com.example.model.AllSymptoms
import com.example.model.ChecklistItem
import com.example.model.CycleStatus
import com.example.model.DailyLog
import com.example.model.EducationArticle
import com.example.model.PastCycle
import com.example.model.UserSettings
import com.example.util.CycleCalculator
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

enum class BloomTab(val label: String, val iconName: String) {
    HOME("Home", "home"),
    CALENDAR("Calendar", "calendar"),
    LOG("Log", "edit"),
    INSIGHTS("Insights", "insights"),
    LEARN("Learn", "book"),
    SETTINGS("Settings", "settings")
}

data class BloomUiState(
    val settings: UserSettings = UserSettings(),
    val cycleStatus: CycleStatus = CycleCalculator.calculateCycleStatus(""),
    val selectedDate: String = DateUtils.today(),
    val selectedDateLog: DailyLog = DailyLog(date = DateUtils.today()),
    val todayLog: DailyLog = DailyLog(date = DateUtils.today()),
    val dailyLogs: Map<String, DailyLog> = emptyMap(),
    val pastCycles: List<PastCycle> = emptyList(),
    val checklist: List<ChecklistItem> = emptyList(),
    val articles: List<EducationArticle> = emptyList(),
    val selectedArticle: EducationArticle? = null,
    val activeTab: BloomTab = BloomTab.HOME,
    val isUnlocked: Boolean = true,
    val showCoachMarks: Boolean = false,
    val reminderBanner: String? = null,
    val showLogSheetDate: String? = null
)

class BloomViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BloomRepository(application)

    private val _selectedDate = MutableStateFlow(DateUtils.today())
    private val _activeTab = MutableStateFlow(BloomTab.HOME)
    private val _selectedArticle = MutableStateFlow<EducationArticle?>(null)
    private val _isUnlocked = MutableStateFlow(false)
    private val _showLogSheetDate = MutableStateFlow<String?>(null)

    val uiState: StateFlow<BloomUiState> = combine(
        repository.settings,
        repository.dailyLogs,
        repository.pastCycles,
        repository.checklist,
        _selectedDate,
        _activeTab,
        _selectedArticle,
        _isUnlocked,
        _showLogSheetDate
    ) { args: Array<Any?> ->
        val settings = args[0] as UserSettings
        @Suppress("UNCHECKED_CAST")
        val dailyLogs = args[1] as Map<String, DailyLog>
        @Suppress("UNCHECKED_CAST")
        val pastCycles = args[2] as List<PastCycle>
        @Suppress("UNCHECKED_CAST")
        val checklist = args[3] as List<ChecklistItem>
        val selectedDate = args[4] as String
        val activeTab = args[5] as BloomTab
        val selectedArticle = args[6] as? EducationArticle
        val isUnlocked = args[7] as Boolean
        val logSheetDate = args[8] as? String

        val today = DateUtils.today()
        val cycleStatus = CycleCalculator.calculateCycleStatus(
            lastPeriodDate = settings.lastPeriodDate,
            configuredCycleLength = settings.averageCycleLength,
            configuredPeriodLength = settings.averagePeriodLength,
            pastCycles = pastCycles,
            today = today
        )

        val selectedLog = dailyLogs[selectedDate] ?: DailyLog(date = selectedDate)
        val todayLog = dailyLogs[today] ?: DailyLog(date = today)

        // Calculate reminder banner message
        val reminderBanner = when {
            cycleStatus.isLate -> {
                "Period is late by ${cycleStatus.lateDays} ${if (cycleStatus.lateDays == 1) "day" else "days"}. Take a breath and rest."
            }
            cycleStatus.daysUntilNextPeriod == 0 -> {
                "Period may start today. Have your essentials ready!"
            }
            cycleStatus.daysUntilNextPeriod in 1..settings.reminderDaysBefore -> {
                "Period expected in ${cycleStatus.daysUntilNextPeriod} ${if (cycleStatus.daysUntilNextPeriod == 1) "day" else "days"}."
            }
            settings.dailyReminder && todayLog.flow == com.example.model.FlowLevel.NONE && todayLog.mood == null -> {
                "How are you feeling today? Take 1 minute to check in with Bloom."
            }
            else -> null
        }

        // Check if unlocked needed
        val effectivelyUnlocked = !settings.isPinEnabled || isUnlocked

        BloomUiState(
            settings = settings,
            cycleStatus = cycleStatus,
            selectedDate = selectedDate,
            selectedDateLog = selectedLog,
            todayLog = todayLog,
            dailyLogs = dailyLogs,
            pastCycles = pastCycles,
            checklist = checklist,
            articles = repository.articles,
            selectedArticle = selectedArticle,
            activeTab = activeTab,
            isUnlocked = effectivelyUnlocked,
            showCoachMarks = settings.hasCompletedOnboarding && !settings.hasSeenCoachMarks,
            reminderBanner = reminderBanner,
            showLogSheetDate = logSheetDate
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BloomUiState()
    )

    fun onTabSelected(tab: BloomTab) {
        _activeTab.value = tab
    }

    fun onDateSelected(dateStr: String) {
        _selectedDate.value = dateStr
    }

    fun openLogForDate(dateStr: String?) {
        _showLogSheetDate.value = dateStr
        if (dateStr != null) {
            _selectedDate.value = dateStr
        }
    }

    fun saveDailyLog(log: DailyLog) {
        repository.saveDailyLog(log)
        _showLogSheetDate.value = null
    }

    fun completeOnboarding(
        name: String,
        cycleLength: Int,
        periodLength: Int,
        lastPeriodDate: String,
        reminderDays: Int,
        dailyReminder: Boolean
    ) {
        repository.completeOnboarding(
            name = name,
            cycleLength = cycleLength,
            periodLength = periodLength,
            lastPeriodDate = lastPeriodDate,
            reminderDays = reminderDays,
            dailyReminder = dailyReminder
        )
    }

    fun dismissCoachMarks() {
        repository.markCoachMarksSeen()
    }

    fun verifyPin(pin: String): Boolean {
        val currentPin = repository.settings.value.pinCode
        return if (currentPin == pin) {
            _isUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun lockApp() {
        if (repository.settings.value.isPinEnabled) {
            _isUnlocked.value = false
        }
    }

    fun toggleDiscreetMode() {
        repository.toggleDiscreetMode()
    }

    fun setThemeMode(mode: String) {
        repository.setThemeMode(mode)
    }

    fun setPin(pin: String, enabled: Boolean) {
        repository.setPin(pin, enabled)
        if (enabled) {
            _isUnlocked.value = true
        }
    }

    fun toggleChecklistItem(id: String) {
        repository.toggleChecklistItem(id)
    }

    fun addCustomChecklistItem(title: String) {
        repository.addCustomChecklistItem(title)
    }

    fun removeChecklistItem(id: String) {
        repository.removeChecklistItem(id)
    }

    fun resetChecklist() {
        repository.resetChecklist()
    }

    fun toggleSampleData(enable: Boolean) {
        repository.toggleSampleData(enable)
    }

    fun deletePastCycle(id: String) {
        repository.deletePastCycle(id)
    }

    fun savePastCycle(cycle: PastCycle) {
        repository.savePastCycle(cycle)
    }

    fun clearAllData() {
        repository.clearData(keepOnboarding = false)
        _isUnlocked.value = true
    }

    fun selectArticle(article: EducationArticle?) {
        _selectedArticle.value = article
    }

    fun exportDataJson(): String {
        return repository.exportDataJson()
    }
}
