# Bloom v2 changes

- Dark mode: all light pastel cards now adapt (daily tip, banner, chips, calendar, insights). Status bar icons follow the app theme.
- Notifications: permission request (onboarding and Settings), notification channel, daily reminder alarm at a chosen time, boot rescheduling, test button, link to phone settings.
- Fingerprint unlock on top of the PIN, auto re-lock after 30 seconds away.
- Profile: photo (private storage), name, age.
- "Made for you": tips matched to age and to the user's cycle and period length (Home and Insights).
- Fixes from v1.1: launch crash (checklist init order), Settings overwriting logs, DST date maths, backups off.
