package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.BloomRepository
import com.example.model.DailyLog
import com.example.model.PastCycle
import com.example.model.UserSettings
import com.example.util.CycleCalculator
import com.example.util.DateUtils

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            val repository = BloomRepository(context)
            val settings = repository.settings.value
            when (intent?.action) {
                ReminderScheduler.ACTION_REMINDER -> {
                    if (settings.notificationsEnabled && settings.hasCompletedOnboarding) {
                        val message = ReminderMessages.build(
                            settings = settings,
                            pastCycles = repository.pastCycles.value,
                            todayLog = repository.dailyLogs.value[DateUtils.today()]
                        )
                        if (message != null) {
                            NotificationHelper.show(context, message.first, message.second)
                        }
                    }
                    // Always plan tomorrow's check
                    ReminderScheduler.schedule(context, settings)
                }
                Intent.ACTION_BOOT_COMPLETED,
                Intent.ACTION_MY_PACKAGE_REPLACED -> ReminderScheduler.schedule(context, settings)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

object ReminderMessages {
    /** Returns (title, text) or null when there is nothing to say today. */
    fun build(settings: UserSettings, pastCycles: List<PastCycle>, todayLog: DailyLog?): Pair<String, String>? {
        val name = settings.name.ifBlank { "Friend" }
        val discreet = settings.isDiscreetMode
        val title = if (discreet) "Daily Journal" else "Bloom \uD83C\uDF38"

        var text: String? = null

        if (settings.lastPeriodDate.isNotBlank()) {
            val status = CycleCalculator.calculateCycleStatus(
                lastPeriodDate = settings.lastPeriodDate,
                configuredCycleLength = settings.averageCycleLength,
                configuredPeriodLength = settings.averagePeriodLength,
                pastCycles = pastCycles
            )
            val daysUntil = status.daysUntilNextPeriod
            text = when {
                status.isLate && status.lateDays <= 7 -> {
                    val n = status.lateDays
                    "Your period is $n ${if (n == 1) "day" else "days"} late. Take a breath, rest, and be kind to yourself."
                }
                status.isLate -> null
                daysUntil == 0 -> "Your period may start today. Keep your essentials close."
                daysUntil == 1 -> "Your period may start tomorrow. Time to get ready: pads, pain relief and a warm drink."
                daysUntil in 2..settings.reminderDaysBefore ->
                    "Your period is expected in $daysUntil days. A good moment to check your Be Ready list."
                else -> null
            }
        }

        if (text == null && settings.dailyReminder && todayLog == null) {
            text = "How are you feeling today, $name? Take a minute to log your day."
        }

        if (text == null) return null
        if (discreet) {
            return Pair(title, "You have a gentle reminder waiting in your journal.")
        }
        return Pair(title, text)
    }
}
