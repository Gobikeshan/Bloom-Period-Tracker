package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.model.UserSettings
import java.util.Calendar

object ReminderScheduler {
    const val ACTION_REMINDER = "com.example.bloom.ACTION_REMINDER"
    private const val REQUEST_CODE = 1001

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).setAction(ACTION_REMINDER)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Schedules (or cancels) the next daily reminder check at the user's chosen time. */
    fun schedule(context: Context, settings: UserSettings) {
        val app = context.applicationContext
        val alarmManager = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pendingIntent(app)

        if (!settings.notificationsEnabled || !settings.hasCompletedOnboarding) {
            alarmManager.cancel(pending)
            return
        }

        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, settings.reminderHour)
            set(Calendar.MINUTE, settings.reminderMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (next.timeInMillis <= System.currentTimeMillis() + 5_000L) {
            next.add(Calendar.DAY_OF_YEAR, 1)
        }

        // Inexact but Doze-friendly alarm: needs no special permission.
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    }
}
