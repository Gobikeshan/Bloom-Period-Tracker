package com.example

import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.example.notifications.NotificationHelper
import com.example.ui.BloomApp
import com.example.ui.BloomViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

// FragmentActivity is needed for the fingerprint prompt. It still works with Compose.
class MainActivity : FragmentActivity() {

    private val viewModel: BloomViewModel by viewModels()
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.ensureChannel(this)
        enableEdgeToEdge()

        // Keep content hidden in the recent-apps overview screen if PIN + FLAG_SECURE are on
        lifecycleScope.launch {
            viewModel.uiState.collectLatest { state ->
                val hideRecent = state.settings.isPinEnabled && state.settings.isFlagSecureEnabled
                if (hideRecent) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }
        }

        setContent {
            BloomApp(viewModel = viewModel)
        }
    }

    override fun onStop() {
        stoppedAt = SystemClock.elapsedRealtime()
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        if (stoppedAt != 0L) {
            val awayMs = SystemClock.elapsedRealtime() - stoppedAt
            val skip = viewModel.consumeSkipLock()
            // Lock again after 30 seconds away from the app
            if (!skip && awayMs > 30_000L) {
                viewModel.lockApp()
            }
        }
    }
}
