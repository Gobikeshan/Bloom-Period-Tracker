package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.BloomRepository
import com.example.util.CycleCalculator
import com.example.util.DateUtils

class BloomWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    companion object {
        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            widgetId: Int
        ) {
            try {
                val repository = BloomRepository(context)
                val settings = repository.settings.value
                val pastCycles = repository.pastCycles.value

                val status = CycleCalculator.calculateCycleStatus(
                    lastPeriodDate = settings.lastPeriodDate,
                    configuredCycleLength = settings.averageCycleLength,
                    configuredPeriodLength = settings.averagePeriodLength,
                    pastCycles = pastCycles
                )

                val views = RemoteViews(context.packageName, R.layout.bloom_widget)

                val dayText = if (status.isLate) {
                    "Late by ${status.lateDays}d"
                } else {
                    "Day ${status.cycleDay}"
                }

                val subText = if (settings.isDiscreetMode) {
                    "Daily Journal • Day ${status.cycleDay}"
                } else if (status.isLate) {
                    "Cycle lingering • Take gentle care"
                } else if (status.daysUntilNextPeriod == 0) {
                    "${status.phase.title} • Period may start today"
                } else {
                    "${status.phase.title} • Next in ${status.daysUntilNextPeriod}d"
                }

                views.setTextViewText(R.id.widget_day_text, dayText)
                views.setTextViewText(R.id.widget_subtext, subText)

                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pending = PendingIntent.getActivity(
                    context,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pending)

                appWidgetManager.updateAppWidget(widgetId, views)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun updateAllWidgets(context: Context) {
            try {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, BloomWidgetProvider::class.java))
                if (ids.isNotEmpty()) {
                    for (id in ids) {
                        updateWidget(context, manager, id)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
