package com.example.util

import com.example.model.CyclePhase
import com.example.ui.BloomTab

object BloomStrings {

    fun tabLabel(tab: BloomTab, lang: String, isDiscreet: Boolean): String {
        if (isDiscreet) {
            return when (lang) {
                "ta" -> when (tab) {
                    BloomTab.HOME -> "நாட்குறிப்பு"
                    BloomTab.CALENDAR -> "திட்டம்"
                    BloomTab.LOG -> "குறிப்புகள்"
                    BloomTab.INSIGHTS -> "போக்குகள்"
                    BloomTab.LEARN -> "கட்டுரைகள்"
                    BloomTab.SETTINGS -> "அமைப்புகள்"
                }
                "si" -> when (tab) {
                    BloomTab.HOME -> "දිනපොත"
                    BloomTab.CALENDAR -> "සැලසුම්කරු"
                    BloomTab.LOG -> "සටහන්"
                    BloomTab.INSIGHTS -> "ප්‍රවණතා"
                    BloomTab.LEARN -> "ලිපි"
                    BloomTab.SETTINGS -> "සැකසුම්"
                }
                else -> when (tab) {
                    BloomTab.HOME -> "Journal"
                    BloomTab.CALENDAR -> "Planner"
                    BloomTab.LOG -> "Notes"
                    BloomTab.INSIGHTS -> "Trends"
                    BloomTab.LEARN -> "Articles"
                    BloomTab.SETTINGS -> "Settings"
                }
            }
        }

        return when (lang) {
            "ta" -> when (tab) {
                BloomTab.HOME -> "முகப்பு"
                BloomTab.CALENDAR -> "நாட்காட்டி"
                BloomTab.LOG -> "பதிவு"
                BloomTab.INSIGHTS -> "விவரங்கள்"
                BloomTab.LEARN -> "கற்றல்"
                BloomTab.SETTINGS -> "அமைப்புகள்"
            }
            "si" -> when (tab) {
                BloomTab.HOME -> "මුල් පිටුව"
                BloomTab.CALENDAR -> "දින දර්ශනය"
                BloomTab.LOG -> "සටහන"
                BloomTab.INSIGHTS -> "විස්තර"
                BloomTab.LEARN -> "ඉගෙන ගන්න"
                BloomTab.SETTINGS -> "සැකසුම්"
            }
            else -> tab.label
        }
    }

    fun phaseTitle(phase: CyclePhase, lang: String): String {
        return when (lang) {
            "ta" -> when (phase) {
                CyclePhase.PERIOD -> "மாதவிடாய்"
                CyclePhase.FOLLICULAR -> "கருமுட்டை வளர்ச்சி"
                CyclePhase.OVULATION -> "கருமுட்டை வெளிப்பாடு"
                CyclePhase.LUTEAL -> "லூட்டியல் கட்டம்"
            }
            "si" -> when (phase) {
                CyclePhase.PERIOD -> "ඔසප් වීම"
                CyclePhase.FOLLICULAR -> "ෆොලිකියුලර්"
                CyclePhase.OVULATION -> "ඩිම්බ මෝචනය"
                CyclePhase.LUTEAL -> "ලුටියල්"
            }
            else -> phase.title
        }
    }

    fun cycleDayText(day: Int, lang: String): String {
        return when (lang) {
            "ta" -> "நாள் $day"
            "si" -> "දිනය $day"
            else -> "Day $day"
        }
    }

    fun daysUntilText(days: Int, isLate: Boolean, lateDays: Int, lang: String): String {
        if (isLate) {
            return when (lang) {
                "ta" -> "மாதவிடாய் $lateDays நாட்கள் தாமதம்"
                "si" -> "ඔසප් වීම දින $lateDays කින් ප්‍රමාදයි"
                else -> "Late by $lateDays ${if (lateDays == 1) "day" else "days"}"
            }
        }
        return when (lang) {
            "ta" -> if (days == 0) "இன்று எதிர்பார்க்கப்படுகிறது" else "அடுத்தது $days நாட்களில்"
            "si" -> if (days == 0) "අද දින බලාපොරොත්තු වේ" else "ඊළඟ එක දින $days කින්"
            else -> if (days == 0) "Period may start today" else "Next in $days days"
        }
    }

    fun beReadyTitle(lang: String): String {
        return when (lang) {
            "ta" -> "'தயாராக இருங்கள்' சரிபார்ப்புப் பட்டியல்"
            "si" -> "'සූදානම් වන්න' පිරික්සුම් ලැයිස්තුව"
            else -> "'Be Ready' Period Checklist"
        }
    }

    fun logTodayButton(lang: String): String {
        return when (lang) {
            "ta" -> "இன்றைய பதிவு"
            "si" -> "අද දින සටහන"
            else -> "Log Today"
        }
    }
}
