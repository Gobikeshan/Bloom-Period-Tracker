package com.example.util

import com.example.model.PastCycle

enum class InsightLevel { GOOD, INFO, CHECK }

data class CycleInsight(
    val emoji: String,
    val title: String,
    val text: String,
    val level: InsightLevel
)

/**
 * General, non-medical guidance matched to age and to the user's measured cycle and period length.
 * Ranges follow common clinical guidance: teens 21 to 45 days, adults 21 to 35 days, bleeding up to 7 days.
 */
object AgeInsights {
    const val MIN_AGE = 9
    const val MAX_AGE = 70

    fun isValidAge(age: Int): Boolean = age in MIN_AGE..MAX_AGE

    fun ageGroupLabel(age: Int): String = when {
        !isValidAge(age) -> "Your profile"
        age < 18 -> "Teen years"
        age < 25 -> "Early adulthood"
        age < 35 -> "Prime reproductive years"
        age < 45 -> "Late reproductive years"
        age < 56 -> "Perimenopause transition"
        else -> "Post-menopause years"
    }

    fun build(
        age: Int,
        cycleLength: Int,
        periodLength: Int,
        pastCycles: List<PastCycle>,
        ovulationDay: Int
    ): List<CycleInsight> {
        if (!isValidAge(age)) {
            return listOf(
                CycleInsight(
                    "\uD83C\uDF38",
                    "Add your age",
                    "Add your age in Settings, Profile to get tips matched to your life stage and your own cycle numbers.",
                    InsightLevel.INFO
                )
            )
        }

        val result = mutableListOf<CycleInsight>()
        val isTeen = age < 18
        val isTransition = age >= 45

        // 1. Cycle length
        result += when {
            isTeen -> if (cycleLength in 21..45) {
                CycleInsight("\uD83D\uDCC5", "Cycle length looks typical",
                    "A $cycleLength-day cycle is within the usual teen range of 21 to 45 days.", InsightLevel.GOOD)
            } else {
                CycleInsight("\uD83D\uDCC5", "Cycle length worth discussing",
                    "A $cycleLength-day cycle is outside the usual teen range of 21 to 45 days. A doctor or school nurse can help you understand it.", InsightLevel.CHECK)
            }
            isTransition -> if (cycleLength in 21..38) {
                CycleInsight("\uD83D\uDCC5", "Cycle length still typical",
                    "Your $cycleLength-day cycle is in the usual range. Cycles often change after 45, so keep logging.", InsightLevel.GOOD)
            } else {
                CycleInsight("\uD83D\uDCC5", "Cycles are shifting",
                    "A $cycleLength-day cycle is common in the 40s and 50s as hormones change. Mention big or sudden changes to your doctor.", InsightLevel.INFO)
            }
            else -> when (cycleLength) {
                in 21..35 -> CycleInsight("\uD83D\uDCC5", "Cycle length looks typical",
                    "A $cycleLength-day cycle is within the usual adult range of 21 to 35 days.", InsightLevel.GOOD)
                in 36..38 -> CycleInsight("\uD83D\uDCC5", "Slightly long cycle",
                    "A $cycleLength-day cycle is a little longer than average but still common. Keep tracking to see your pattern.", InsightLevel.INFO)
                else -> CycleInsight("\uD83D\uDCC5", "Cycle length worth discussing",
                    "A $cycleLength-day cycle is outside the common 21 to 38 day range. Consider talking to a doctor, especially if it changed recently.", InsightLevel.CHECK)
            }
        }

        // 2. Period length
        result += when {
            periodLength > 7 -> CycleInsight("\uD83E\uDE78", "Long period",
                "Bleeding for more than 7 days is worth mentioning to a doctor, especially if the flow is heavy.", InsightLevel.CHECK)
            periodLength >= 2 -> CycleInsight("\uD83E\uDE78", "Period length looks typical",
                "$periodLength days is within the usual 2 to 7 day range.", InsightLevel.GOOD)
            else -> CycleInsight("\uD83E\uDE78", "Very short period",
                "A 1-day period can be normal for some people. If it changed recently, note it in your log.", InsightLevel.INFO)
        }

        // 3. Regularity from logged cycles
        val lengths = pastCycles.map { it.cycleLength }.filter { it in 15..60 }
        if (lengths.size >= 2) {
            val spread = lengths.max() - lengths.min()
            result += if (spread <= 7) {
                CycleInsight("\uD83C\uDF0A", "Steady rhythm",
                    "Your logged cycles vary by about $spread days, which is a regular pattern.", InsightLevel.GOOD)
            } else {
                val why = when {
                    isTeen -> "This is very common in the first years after periods begin."
                    isTransition -> "This is common during the transition toward menopause."
                    else -> "Stress, sleep, travel and illness can all shift timing. If it keeps happening, ask a doctor."
                }
                CycleInsight("\uD83C\uDF0A", "Cycles vary quite a bit",
                    "Your logged cycles differ by about $spread days. $why", InsightLevel.INFO)
            }
        }

        // 4. Fertile window estimate (adults only)
        if (age in 18..49) {
            result += CycleInsight(
                "\u2728", "Estimated fertile window",
                "Ovulation is estimated around cycle day $ovulationDay, with fertile days from day ${ovulationDay - 5} to day ${ovulationDay + 1}. This is an estimate and not contraception.",
                InsightLevel.INFO
            )
        }

        // 5. Life-stage tips
        result += when {
            isTeen -> listOf(
                CycleInsight("\uD83E\uDD6C", "Iron and energy",
                    "Periods can lower iron. Pair iron-rich foods (lentils, beans, spinach, eggs) with vitamin C, and aim for 8 to 10 hours of sleep.", InsightLevel.INFO),
                CycleInsight("\uD83D\uDCD3", "Irregular is common early on",
                    "Cycles often take 2 to 3 years after the first period to settle. Keep logging and be patient with your body.", InsightLevel.INFO)
            )
            age < 25 -> listOf(
                CycleInsight("\uD83E\uDDD8", "Stress and sleep matter",
                    "Exams, work and late nights can shift your cycle by a few days. Regular sleep and movement help keep it steady.", InsightLevel.INFO),
                CycleInsight("\uD83E\uDD57", "Eat for steady energy",
                    "Regular meals with protein, iron and magnesium can ease tiredness and cramps.", InsightLevel.INFO)
            )
            age < 35 -> listOf(
                CycleInsight("\uD83C\uDF3F", "Know your pattern",
                    "Your log is most useful now. Note mood, energy and ovulation signs to see your own pattern.", InsightLevel.INFO),
                CycleInsight("\uD83D\uDCA7", "Folate-rich foods",
                    "Leafy greens, beans and citrus support general health. If you may plan a pregnancy, ask your doctor about folic acid.", InsightLevel.INFO)
            )
            age < 45 -> listOf(
                CycleInsight("\uD83C\uDFCB\uFE0F", "Protect your bones",
                    "Strength training, calcium and vitamin D support bone health as hormones begin to shift.", InsightLevel.INFO),
                CycleInsight("\uD83E\uDE7A", "Watch flow changes",
                    "Heavier or longer periods become more common. If flow soaks a pad or tampon every hour, speak to a doctor.", InsightLevel.INFO)
            )
            age < 56 -> listOf(
                CycleInsight("\uD83C\uDF21\uFE0F", "Perimenopause signs",
                    "Hot flashes, night sweats, poor sleep and skipped periods can start now. Logging symptoms helps your doctor.", InsightLevel.INFO),
                CycleInsight("\uD83E\uDE7A", "When to get checked",
                    "Very heavy bleeding, bleeding between periods, or any bleeding after 12 months without a period should be checked by a doctor.", InsightLevel.CHECK)
            )
            else -> listOf(
                CycleInsight("\uD83E\uDE7A", "Bleeding after menopause",
                    "Any bleeding after 12 months without a period should be checked by a doctor promptly.", InsightLevel.CHECK),
                CycleInsight("\uD83E\uDDB4", "Bone and heart health",
                    "Calcium, vitamin D, walking and strength exercises support long-term health.", InsightLevel.INFO)
            )
        }

        return result
    }
}
