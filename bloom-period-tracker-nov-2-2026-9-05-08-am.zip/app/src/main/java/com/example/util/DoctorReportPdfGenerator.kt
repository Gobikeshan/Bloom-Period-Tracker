package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.model.AllSymptoms
import com.example.model.DailyLog
import com.example.model.PastCycle
import com.example.model.UserSettings
import java.io.File
import java.io.FileOutputStream

object DoctorReportPdfGenerator {

    fun generate(
        context: Context,
        settings: UserSettings,
        pastCycles: List<PastCycle>,
        dailyLogs: Map<String, DailyLog>
    ): File? {
        return try {
            val document = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(74, 26, 44) // Deep plum
                textSize = 22f
                isFakeBoldText = true
            }
            val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(124, 99, 109) // Text secondary
                textSize = 10f
            }
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(53, 23, 34) // Text primary
                textSize = 11f
            }
            val boldTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(53, 23, 34)
                textSize = 11f
                isFakeBoldText = true
            }
            val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(253, 232, 236) // Blush light
            }
            val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(248, 245, 246)
            }
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(230, 220, 224)
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            val accentLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(226, 115, 143) // Blush primary
                strokeWidth = 3f
            }

            var y = 45f

            // Top decorative bar
            canvas.drawLine(40f, y, 555f, y, accentLinePaint)
            y += 24f

            // Document Header
            val headerTitle = if (settings.isDiscreetMode) "Personal Cycle & Health Summary" else "Bloom — Menstrual Cycle Health Summary"
            canvas.drawText(headerTitle, 40f, y, titlePaint)
            y += 14f
            canvas.drawText("Confidential Patient-Tracked Record • Generated ${DateUtils.formatDisplay(DateUtils.today())}", 40f, y, subtitlePaint)
            y += 24f

            // Patient Info Box
            val infoBox = RectF(40f, y, 555f, y + 48f)
            canvas.drawRoundRect(infoBox, 8f, 8f, cardBgPaint)
            canvas.drawRoundRect(infoBox, 8f, 8f, borderPaint)

            val displayName = if (settings.isDiscreetMode) "Patient" else settings.name.ifBlank { "Patient" }
            val displayAge = if (settings.age > 0) "${settings.age} years" else "Not provided"

            canvas.drawText("Name: $displayName", 55f, y + 20f, boldTextPaint)
            canvas.drawText("Age: $displayAge", 220f, y + 20f, textPaint)
            canvas.drawText("Cycles Tracked: ${pastCycles.size}", 380f, y + 20f, textPaint)

            canvas.drawText("Average Cycle Length: ${settings.averageCycleLength} days", 55f, y + 38f, textPaint)
            canvas.drawText("Average Bleeding: ${settings.averagePeriodLength} days", 220f, y + 38f, textPaint)
            canvas.drawText("Last Period: ${if (settings.lastPeriodDate.isNotBlank()) DateUtils.formatDisplay(settings.lastPeriodDate) else "N/A"}", 380f, y + 38f, textPaint)

            y += 66f

            // Section: Recent Cycles
            canvas.drawText("Recorded Cycle History (Last 6 Cycles)", 40f, y, Paint(titlePaint).apply { textSize = 14f })
            y += 14f

            // Table Header
            val tableTop = y
            val tableHeaderRect = RectF(40f, tableTop, 555f, tableTop + 24f)
            canvas.drawRoundRect(tableHeaderRect, 4f, 4f, headerBgPaint)

            val col1 = 50f   // Cycle #
            val col2 = 120f  // Start Date
            val col3 = 230f  // End Date
            val col4 = 340f  // Cycle Length
            val col5 = 440f  // Period Days

            canvas.drawText("Cycle #", col1, tableTop + 16f, boldTextPaint)
            canvas.drawText("Start Date", col2, tableTop + 16f, boldTextPaint)
            canvas.drawText("End Date", col3, tableTop + 16f, boldTextPaint)
            canvas.drawText("Cycle Length", col4, tableTop + 16f, boldTextPaint)
            canvas.drawText("Flow Days", col5, tableTop + 16f, boldTextPaint)

            y = tableTop + 26f

            val recentCycles = pastCycles.take(6)
            if (recentCycles.isEmpty()) {
                canvas.drawText("No completed historical cycles recorded yet.", col1, y + 18f, subtitlePaint)
                y += 28f
            } else {
                recentCycles.forEachIndexed { index, cycle ->
                    val rowRect = RectF(40f, y, 555f, y + 22f)
                    if (index % 2 == 1) {
                        canvas.drawRect(rowRect, cardBgPaint)
                    }
                    canvas.drawText("#${index + 1}", col1, y + 15f, textPaint)
                    canvas.drawText(DateUtils.formatDisplay(cycle.startDate), col2, y + 15f, textPaint)
                    val endStr = if (!cycle.endDate.isNullOrBlank()) DateUtils.formatDisplay(cycle.endDate) else "—"
                    canvas.drawText(endStr, col3, y + 15f, textPaint)
                    canvas.drawText("${cycle.cycleLength} days", col4, y + 15f, textPaint)
                    canvas.drawText("${cycle.periodLength} days", col5, y + 15f, textPaint)

                    y += 22f
                }
            }

            y += 16f

            // Section: Symptoms Frequency Summary
            canvas.drawText("Recorded Symptoms & Patterns", 40f, y, Paint(titlePaint).apply { textSize = 14f })
            y += 14f

            val symptomCounts = mutableMapOf<String, Int>()
            dailyLogs.values.forEach { log ->
                log.symptoms.forEach { id ->
                    symptomCounts[id] = (symptomCounts[id] ?: 0) + 1
                }
            }

            val sympBox = RectF(40f, y, 555f, y + 70f)
            canvas.drawRoundRect(sympBox, 8f, 8f, cardBgPaint)
            canvas.drawRoundRect(sympBox, 8f, 8f, borderPaint)

            if (symptomCounts.isEmpty()) {
                canvas.drawText("No physical symptoms logged during this period.", 55f, y + 25f, subtitlePaint)
            } else {
                val sortedSymps = symptomCounts.entries.sortedByDescending { it.value }.take(6)
                var colX = 55f
                var rowY = y + 22f
                sortedSymps.forEachIndexed { i, entry ->
                    val sympLabel = AllSymptoms.find { it.id == entry.key }?.label ?: entry.key
                    canvas.drawText("• $sympLabel: ${entry.value} logged", colX, rowY, textPaint)
                    if (i % 2 == 1) {
                        colX = 55f
                        rowY += 18f
                    } else {
                        colX = 300f
                    }
                }
            }

            y += 86f

            // Section: Clinical Disclaimer Box
            val disclaimerBox = RectF(40f, y, 555f, y + 54f)
            val disclaimerBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(243, 238, 252) } // Lavender light
            canvas.drawRoundRect(disclaimerBox, 8f, 8f, disclaimerBg)
            canvas.drawRoundRect(disclaimerBox, 8f, 8f, borderPaint)

            val disclaimerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(74, 26, 44)
                textSize = 9.5f
            }
            canvas.drawText("CLINICAL NOTE: This document aggregates self-recorded menstrual flow and bodily symptom entries", 55f, y + 18f, Paint(disclaimerPaint).apply { isFakeBoldText = true })
            canvas.drawText("for discussion with a licensed medical professional. It does not replace clinical evaluation or diagnostic tests.", 55f, y + 32f, disclaimerPaint)
            canvas.drawText("All data is stored locally on device and exported with patient authorization.", 55f, y + 44f, disclaimerPaint)

            // Footer
            canvas.drawText("Page 1 of 1 • Bloom Health Companion", 230f, 810f, subtitlePaint)

            document.finishPage(page)

            val reportFile = File(context.cacheDir, "bloom_doctor_report.pdf")
            FileOutputStream(reportFile).use { out ->
                document.writeTo(out)
            }
            document.close()
            reportFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareReport(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Bloom Menstrual Cycle Report")
            putExtra(Intent.EXTRA_TEXT, "Here is my personal menstrual cycle and symptom history exported from Bloom.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(sendIntent, "Share or Save Doctor Report")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun generateAndShare(
        context: Context,
        settings: UserSettings,
        pastCycles: List<PastCycle>,
        dailyLogs: Map<String, DailyLog>
    ): Boolean {
        val file = generate(context, settings, pastCycles, dailyLogs) ?: return false
        shareReport(context, file)
        return true
    }
}
