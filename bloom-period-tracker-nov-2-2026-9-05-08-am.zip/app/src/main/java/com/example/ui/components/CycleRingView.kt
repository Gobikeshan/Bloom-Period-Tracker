package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CyclePhase
import com.example.model.CycleStatus
import com.example.ui.theme.DeepPlum
import com.example.ui.theme.PhaseFollicular
import com.example.ui.theme.PhaseLuteal
import com.example.ui.theme.PhaseOvulation
import com.example.ui.theme.PhasePeriod
import com.example.ui.theme.adaptiveTint
import com.example.util.BloomStrings
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CycleRingView(
    cycleStatus: CycleStatus,
    isDiscreetMode: Boolean = false,
    isPregnancyMode: Boolean = false,
    appLanguage: String = "en",
    isHighContrast: Boolean = false,
    modifier: Modifier = Modifier,
    size: Dp = 250.dp
) {
    val totalDays = cycleStatus.totalCycleDays.coerceAtLeast(20).toFloat()
    val currentDay = cycleStatus.cycleDay.coerceAtMost(cycleStatus.totalCycleDays + 5).toFloat()

    val progress = (currentDay / totalDays).coerceIn(0.01f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
        label = "cycleProgress"
    )

    // Calculate angles for 4 phases:
    val periodFraction = 5f / totalDays
    val follicularFraction = (totalDays - 14f - 5f).coerceAtLeast(4f) / totalDays
    val ovulationFraction = 3f / totalDays
    val lutealFraction = (1f - periodFraction - follicularFraction - ovulationFraction).coerceAtLeast(0.1f)

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = if (isHighContrast) 22.dp.toPx() else 18.dp.toPx()
            val arcSize = Size(this.size.width - strokeWidth * 2, this.size.height - strokeWidth * 2)
            val topLeft = Offset(strokeWidth, strokeWidth)
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = (this.size.width - strokeWidth * 2) / 2f

            var currentAngle = -90f
            val spacingAngle = 3f

            // 1. Period Arc
            val periodAngle = (360f * periodFraction) - spacingAngle
            drawArc(
                color = PhasePeriod,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = periodAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentAngle += periodAngle + spacingAngle

            // 2. Follicular Arc
            val follicularAngle = (360f * follicularFraction) - spacingAngle
            drawArc(
                color = PhaseFollicular,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = follicularAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentAngle += follicularAngle + spacingAngle

            // 3. Ovulation Arc
            val ovulationAngle = (360f * ovulationFraction) - spacingAngle
            drawArc(
                color = PhaseOvulation,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = ovulationAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentAngle += ovulationAngle + spacingAngle

            // 4. Luteal Arc
            val lutealAngle = (360f - (currentAngle - (-90f))) - spacingAngle
            drawArc(
                color = PhaseLuteal,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = lutealAngle.coerceAtLeast(5f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Current Day indicator position on the ring
            val indicatorAngleRad = Math.toRadians(((-90f) + (360f * animatedProgress)).toDouble())
            val markerX = center.x + radius * cos(indicatorAngleRad).toFloat()
            val markerY = center.y + radius * sin(indicatorAngleRad).toFloat()

            // Outer ring
            drawCircle(
                color = Color.White.copy(alpha = 0.95f),
                radius = strokeWidth * 0.75f,
                center = Offset(markerX, markerY)
            )
            if (isHighContrast) {
                drawCircle(
                    color = Color.Black,
                    radius = strokeWidth * 0.8f,
                    center = Offset(markerX, markerY),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
            // Inner colored pin
            drawCircle(
                color = cycleStatus.phase.color,
                radius = strokeWidth * 0.45f,
                center = Offset(markerX, markerY)
            )
        }

        // Center Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(28.dp)
        ) {
            if (cycleStatus.isLate) {
                Text(
                    text = if (appLanguage == "ta") "தாமதம்" else if (appLanguage == "si") "ප්‍රමාදයි" else "Late by",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${cycleStatus.lateDays}d",
                    style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
                    color = PhasePeriod
                )
            } else {
                Text(
                    text = if (isDiscreetMode) "Tracking" else if (appLanguage == "ta") "சுழற்சி" else if (appLanguage == "si") "චක්‍රය" else "Cycle",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = BloomStrings.cycleDayText(cycleStatus.cycleDay, appLanguage),
                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Phase chip badge
            val phaseLabel = if (isDiscreetMode) {
                "Phase ${cycleStatus.phase.ordinal + 1}"
            } else {
                BloomStrings.phaseTitle(cycleStatus.phase, appLanguage)
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = adaptiveTint(cycleStatus.phase.color, cycleStatus.phase.bgColor)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = cycleStatus.phase.iconEmoji,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text(
                        text = phaseLabel,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = cycleStatus.phase.color
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = BloomStrings.daysUntilText(
                    days = cycleStatus.daysUntilNextPeriod,
                    isLate = cycleStatus.isLate,
                    lateDays = cycleStatus.lateDays,
                    lang = appLanguage
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            // Optional Pregnancy Planning Badge
            if (isPregnancyMode && !isDiscreetMode) {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = PhaseOvulation.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "Fertility: ${cycleStatus.conceptionChance}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = PhaseOvulation,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
