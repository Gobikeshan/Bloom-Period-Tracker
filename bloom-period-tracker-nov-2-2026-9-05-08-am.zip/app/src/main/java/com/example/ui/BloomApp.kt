package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CoachMarksOverlay
import com.example.ui.components.PinLockView
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.DailyLogScreen
import com.example.ui.screens.EducationScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InsightsScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BloomTheme
import com.example.ui.theme.BlushLight
import com.example.ui.theme.BlushPrimary
import com.example.ui.theme.DeepPlum
import com.example.util.DateUtils
import androidx.compose.ui.platform.LocalContext
import com.example.util.BiometricHelper

import com.example.util.BloomStrings

@Composable
fun BloomApp(
    viewModel: BloomViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    val darkTheme = when (uiState.settings.themeMode) {
        "DARK" -> true
        "LIGHT" -> false
        else -> isSystemInDarkTheme()
    }

    BloomTheme(darkTheme = darkTheme) {
        // If not completed onboarding, show onboarding flow
        if (!uiState.settings.hasCompletedOnboarding) {
            OnboardingScreen(
                onComplete = { name, cycleLength, periodLength, lastPeriodDate, reminderDays, dailyReminder, age ->
                    viewModel.completeOnboarding(
                        name = name,
                        cycleLength = cycleLength,
                        periodLength = periodLength,
                        lastPeriodDate = lastPeriodDate,
                        reminderDays = reminderDays,
                        dailyReminder = dailyReminder,
                        age = age
                    )
                }
            )
        } else if (!uiState.isUnlocked) {
            // PIN Lock screen
            PinLockView(
                onUnlock = { pin -> viewModel.verifyPin(pin) },
                isDiscreetMode = uiState.settings.isDiscreetMode,
                showBiometric = uiState.settings.isBiometricEnabled && BiometricHelper.isAvailable(context),
                onBiometricSuccess = { viewModel.unlockWithBiometric() }
            )
        } else {
            // Main App with Navigation
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = {
                    BloomBottomNav(
                        activeTab = uiState.activeTab,
                        onTabSelected = { viewModel.onTabSelected(it) },
                        isDiscreetMode = uiState.settings.isDiscreetMode,
                        appLanguage = uiState.settings.appLanguage
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AnimatedContent(
                        targetState = uiState.activeTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tabTransition"
                    ) { tab ->
                        when (tab) {
                            BloomTab.HOME -> {
                                HomeScreen(
                                    uiState = uiState,
                                    onOpenLog = { date -> viewModel.openLogForDate(date) },
                                    onToggleChecklistItem = { id -> viewModel.toggleChecklistItem(id) },
                                    onAddChecklistItem = { title -> viewModel.addCustomChecklistItem(title) },
                                    onRemoveChecklistItem = { id -> viewModel.removeChecklistItem(id) },
                                    onResetChecklist = { viewModel.resetChecklist() },
                                    onQuickWaterDrink = {
                                        val today = DateUtils.today()
                                        val curLog = uiState.todayLog
                                        val newLog = curLog.copy(
                                            waterGlasses = (curLog.waterGlasses + 1).coerceAtMost(16)
                                        )
                                        viewModel.saveDailyLog(newLog)
                                    },
                                    onOpenLateGuide = {
                                        val lateArt = uiState.articles.find { it.id == "art_late_period" }
                                        viewModel.selectArticle(lateArt)
                                        viewModel.onTabSelected(BloomTab.LEARN)
                                    }
                                )
                            }
                            BloomTab.CALENDAR -> {
                                CalendarScreen(
                                    uiState = uiState,
                                    onSelectDate = { date -> viewModel.onDateSelected(date) },
                                    onOpenLog = { date -> viewModel.openLogForDate(date) }
                                )
                            }
                            BloomTab.LOG -> {
                                DailyLogScreen(
                                    initialDate = uiState.selectedDate,
                                    existingLog = uiState.selectedDateLog,
                                    onSaveLog = { log -> viewModel.saveDailyLog(log) },
                                    onClose = { viewModel.onTabSelected(BloomTab.HOME) }
                                )
                            }
                            BloomTab.INSIGHTS -> {
                                InsightsScreen(
                                    uiState = uiState,
                                    onSavePastCycle = { cycle -> viewModel.savePastCycle(cycle) },
                                    onDeletePastCycle = { id -> viewModel.deletePastCycle(id) }
                                )
                            }
                            BloomTab.LEARN -> {
                                EducationScreen(
                                    uiState = uiState,
                                    onSelectArticle = { article -> viewModel.selectArticle(article) }
                                )
                            }
                            BloomTab.SETTINGS -> {
                                SettingsScreen(
                                    uiState = uiState,
                                    onUpdateSettings = { s -> viewModel.updateCycleSettings(s) },
                                    onToggleSampleData = { enable -> viewModel.toggleSampleData(enable) },
                                    onToggleDiscreetMode = { viewModel.toggleDiscreetMode() },
                                    onSetThemeMode = { mode -> viewModel.setThemeMode(mode) },
                                    onSetPin = { pin, enable -> viewModel.setPin(pin, enable) },
                                    onClearAllData = { viewModel.clearAllData() },
                                    onExportDataJson = { viewModel.exportDataJson() },
                                    onSaveProfile = { name, age -> viewModel.updateProfile(name, age) },
                                    onPickPhoto = { uri -> viewModel.setProfilePhoto(uri) },
                                    onRemovePhoto = { viewModel.removeProfilePhoto() },
                                    onSetNotifications = { enabled -> viewModel.setNotificationsEnabled(enabled) },
                                    onSetReminderTime = { h, m -> viewModel.setReminderTime(h, m) },
                                    onSetBiometric = { enabled -> viewModel.setBiometricEnabled(enabled) },
                                    onExternalFlow = { viewModel.skipNextLock() },
                                    onToggleFlagSecure = { viewModel.toggleFlagSecure() },
                                    onTogglePregnancyMode = { viewModel.togglePregnancyMode() },
                                    onSetAppLanguage = { lang -> viewModel.setAppLanguage(lang) },
                                    onToggleHighContrast = { viewModel.toggleHighContrast() },
                                    onImportBackupJson = { json -> viewModel.importBackupJson(json) }
                                )
                            }
                        }
                    }

                    // Coach Marks Overlay (shown right after onboarding)
                    if (uiState.showCoachMarks) {
                        CoachMarksOverlay(
                            onDismiss = { viewModel.dismissCoachMarks() }
                        )
                    }

                    // Floating Daily Log Modal (when opened from Home or Calendar)
                    uiState.showLogSheetDate?.let { date ->
                        DailyLogScreen(
                            initialDate = date,
                            existingLog = uiState.dailyLogs[date] ?: com.example.model.DailyLog(date = date),
                            onSaveLog = { log -> viewModel.saveDailyLog(log) },
                            onClose = { viewModel.openLogForDate(null) }
                        )
                    }
                }
            }

            // Back handler to navigate back to Home if in another tab
            if (uiState.activeTab != BloomTab.HOME) {
                BackHandler {
                    viewModel.onTabSelected(BloomTab.HOME)
                }
            }
        }
    }
}

@Composable
fun BloomBottomNav(
    activeTab: BloomTab,
    onTabSelected: (BloomTab) -> Unit,
    isDiscreetMode: Boolean,
    appLanguage: String = "en",
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.testTag("bloom_bottom_navigation"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        val navItems = listOf(
            Triple(BloomTab.HOME, BloomStrings.tabLabel(BloomTab.HOME, appLanguage, isDiscreetMode), Pair(Icons.Filled.Home, Icons.Outlined.Home)),
            Triple(BloomTab.CALENDAR, BloomStrings.tabLabel(BloomTab.CALENDAR, appLanguage, isDiscreetMode), Pair(Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth)),
            Triple(BloomTab.LOG, BloomStrings.tabLabel(BloomTab.LOG, appLanguage, isDiscreetMode), Pair(Icons.Filled.Edit, Icons.Outlined.Edit)),
            Triple(BloomTab.INSIGHTS, BloomStrings.tabLabel(BloomTab.INSIGHTS, appLanguage, isDiscreetMode), Pair(Icons.Filled.Insights, Icons.Outlined.Insights)),
            Triple(BloomTab.LEARN, BloomStrings.tabLabel(BloomTab.LEARN, appLanguage, isDiscreetMode), Pair(Icons.Filled.Book, Icons.Outlined.Book)),
            Triple(BloomTab.SETTINGS, BloomStrings.tabLabel(BloomTab.SETTINGS, appLanguage, isDiscreetMode), Pair(Icons.Filled.Settings, Icons.Outlined.Settings))
        )

        navItems.forEach { (tab, label, icons) ->
            val isSelected = activeTab == tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) icons.first else icons.second,
                        contentDescription = label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BlushPrimary,
                    selectedTextColor = BlushPrimary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    indicatorColor = BlushLight
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
