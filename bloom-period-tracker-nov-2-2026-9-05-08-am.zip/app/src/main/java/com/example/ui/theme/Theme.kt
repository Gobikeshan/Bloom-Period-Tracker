package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import android.app.Activity
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DeepPlum,
    primaryContainer = Color(0xFF5A2D40),
    onPrimaryContainer = DarkPrimary,
    secondary = DarkSecondary,
    onSecondary = DeepPlum,
    secondaryContainer = Color(0xFF45365C),
    onSecondaryContainer = DarkTextPrimary,
    tertiary = DarkDeepPlum,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkSurfaceVariant,
    outlineVariant = Color(0xFF4A3444)
)

private val LightColorScheme = lightColorScheme(
    primary = BlushPrimary,
    onPrimary = Color.White,
    primaryContainer = BlushLight,
    onPrimaryContainer = DeepPlum,
    secondary = LavenderAccent,
    onSecondary = Color.White,
    secondaryContainer = LavenderLight,
    onSecondaryContainer = DeepPlum,
    tertiary = DeepPlum,
    onTertiary = Color.White,
    background = CreamBackground,
    onBackground = TextPrimary,
    surface = CreamSurface,
    onSurface = TextPrimary,
    surfaceVariant = CreamSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BlushBorder,
    outlineVariant = Color(0xFFF2DEE4)
)

@Composable
fun BloomTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    // Make the status bar and navigation bar icons readable in both light and dark themes
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !darkTheme
                controller.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = BloomTypography,
        content = content
    )
}

/**
 * Soft tinted background for cards: the pastel colour in light mode,
 * and a dark version of the same hue in dark mode so text stays readable.
 */
@Composable
fun adaptiveTint(accent: Color, lightBackground: Color): Color {
    val surface = MaterialTheme.colorScheme.surface
    return if (surface.luminance() < 0.5f) {
        accent.copy(alpha = 0.18f).compositeOver(surface)
    } else {
        lightBackground
    }
}
