package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PastCycle
import com.example.ui.theme.PhaseOvulation
import com.example.util.AgeInsights
import com.example.util.InsightLevel

@Composable
fun AgeInsightsCard(
    age: Int,
    cycleLength: Int,
    periodLength: Int,
    pastCycles: List<PastCycle>,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val ovulationDay = (cycleLength - 14).coerceAtLeast(periodLength + 1)
    val insights = remember(age, cycleLength, periodLength, pastCycles, ovulationDay) {
        AgeInsights.build(age, cycleLength, periodLength, pastCycles, ovulationDay)
    }
    val shown = if (compact) insights.take(2) else insights

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "\u2728", fontSize = 22.sp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Made for you",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (AgeInsights.isValidAge(age)) {
                            "${AgeInsights.ageGroupLabel(age)} \u2022 $age years"
                        } else {
                            AgeInsights.ageGroupLabel(age)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            shown.forEach { insight ->
                Spacer(modifier = Modifier.height(14.dp))
                val badgeColor = when (insight.level) {
                    InsightLevel.GOOD -> Color(0xFF4CAF7D).copy(alpha = 0.2f)
                    InsightLevel.INFO -> MaterialTheme.colorScheme.secondaryContainer
                    InsightLevel.CHECK -> PhaseOvulation.copy(alpha = 0.25f)
                }
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(badgeColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = insight.emoji, fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = insight.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = insight.text,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (!compact) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "General information based on your age and the numbers you entered. Not medical advice. Talk to a doctor if you are worried.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
