package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.UserSettings
import com.example.ui.BloomUiState
import com.example.ui.theme.BlushLight
import com.example.ui.theme.BlushPrimary
import com.example.ui.theme.DeepPlum
import com.example.ui.theme.LavenderAccent
import com.example.ui.theme.LavenderLight
import kotlin.math.roundToInt
import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.input.KeyboardType
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.notifications.NotificationHelper
import com.example.ui.components.ProfileAvatar
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Upload
import com.example.util.AgeInsights
import com.example.util.BiometricHelper
import com.example.util.findFragmentActivity
import com.example.util.DoctorReportPdfGenerator
import com.example.util.BloomStrings

@Composable
fun SettingsScreen(
    uiState: BloomUiState,
    onUpdateSettings: (UserSettings) -> Unit,
    onToggleSampleData: (Boolean) -> Unit,
    onToggleDiscreetMode: () -> Unit,
    onSetThemeMode: (String) -> Unit,
    onSetPin: (String, Boolean) -> Unit,
    onClearAllData: () -> Unit,
    onExportDataJson: () -> String,
    onSaveProfile: (String, Int) -> Unit,
    onPickPhoto: (Uri) -> Unit,
    onRemovePhoto: () -> Unit,
    onSetNotifications: (Boolean) -> Unit,
    onSetReminderTime: (Int, Int) -> Unit,
    onSetBiometric: (Boolean) -> Unit,
    onExternalFlow: () -> Unit,
    onToggleFlagSecure: () -> Unit = {},
    onTogglePregnancyMode: () -> Unit = {},
    onSetAppLanguage: (String) -> Unit = {},
    onToggleHighContrast: () -> Unit = {},
    onImportBackupJson: (String) -> Boolean = { false },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings = uiState.settings

    // Photo picker (no storage permission needed)
    val photoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onPickPhoto(uri)
    }

    // Notification permission (Android 13+) and live status
    var canPostNotifications by remember { mutableStateOf(NotificationHelper.canPost(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        canPostNotifications = NotificationHelper.canPost(context)
    }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        canPostNotifications = NotificationHelper.canPost(context)
        if (granted) {
            onSetNotifications(true)
        } else {
            Toast.makeText(
                context,
                "Notifications are blocked. Tap 'Open phone settings' to allow them.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    var showPinDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    var cycleLength by remember(settings.averageCycleLength) { mutableIntStateOf(settings.averageCycleLength) }
    var periodLength by remember(settings.averagePeriodLength) { mutableIntStateOf(settings.averagePeriodLength) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Settings & Privacy",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Customise your experience and manage local data.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Profile
        item {
            var nameInput by rememberSaveable(settings.name) { mutableStateOf(settings.name) }
            var ageInput by rememberSaveable(settings.age) {
                mutableStateOf(if (settings.age > 0) settings.age.toString() else "")
            }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "My Profile",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    ProfileAvatar(
                        photoPath = settings.photoPath,
                        name = settings.name,
                        size = 96.dp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                onExternalFlow()
                                photoLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("profile_photo_button")
                        ) {
                            Text(
                                text = if (settings.photoPath.isBlank()) "Add photo" else "Change photo",
                                color = BlushPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (settings.photoPath.isNotBlank()) {
                            TextButton(onClick = onRemovePhoto) {
                                Text(text = "Remove", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it.take(24) },
                        label = { Text("Name or nickname") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = ageInput,
                        onValueChange = { ageInput = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Age") },
                        supportingText = { Text("Used for tips that fit your life stage (${AgeInsights.MIN_AGE} to ${AgeInsights.MAX_AGE}).") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_age_input")
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val age = ageInput.toIntOrNull() ?: 0
                            if (ageInput.isNotEmpty() && !AgeInsights.isValidAge(age)) {
                                Toast.makeText(
                                    context,
                                    "Please enter an age between ${AgeInsights.MIN_AGE} and ${AgeInsights.MAX_AGE}.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                onSaveProfile(nameInput.trim(), age)
                                Toast.makeText(context, "Profile saved", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("profile_save_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary)
                    ) {
                        Text("Save profile", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Notifications
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = BlushPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Notifications",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Phone reminders",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Pop-up reminders before your period, even when Bloom is closed.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.notificationsEnabled,
                            onCheckedChange = { enable ->
                                if (enable && NotificationHelper.needsPermission(context)) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onSetNotifications(enable)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BlushPrimary),
                            modifier = Modifier.testTag("notifications_switch")
                        )
                    }

                    if (settings.notificationsEnabled && !canPostNotifications) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Notifications are blocked for Bloom on this phone, so reminders cannot appear.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        TextButton(onClick = { NotificationHelper.openSystemSettings(context) }) {
                            Text("Open phone settings", color = BlushPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (settings.notificationsEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Reminder time: ${formatClock(settings.reminderHour, settings.reminderMinute)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(8 to 0, 9 to 0, 18 to 0, 21 to 0).forEach { (h, m) ->
                                val isSelected = settings.reminderHour == h && settings.reminderMinute == m
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) BlushPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { onSetReminderTime(h, m) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = formatClock(h, m),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(onClick = {
                                val total = (settings.reminderHour * 60 + settings.reminderMinute - 15 + 1440) % 1440
                                onSetReminderTime(total / 60, total % 60)
                            }) {
                                Text("- 15 min", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = {
                                val total = (settings.reminderHour * 60 + settings.reminderMinute + 15) % 1440
                                onSetReminderTime(total / 60, total % 60)
                            }) {
                                Text("+ 15 min", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (NotificationHelper.needsPermission(context)) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                val shown = NotificationHelper.show(
                                    context,
                                    "Bloom \uD83C\uDF38",
                                    "Test notification: your reminders are working!"
                                )
                                if (!shown) {
                                    Toast.makeText(
                                        context,
                                        "Notifications are blocked. Open phone settings to allow them.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("test_notification_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(
                            text = "Send a test notification",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Tip: if reminders arrive late, set Bloom's battery mode to \"No restrictions\" in your phone settings.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Cycle Calibration
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Cycle Parameters",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Average Cycle Length", style = MaterialTheme.typography.bodyMedium)
                        Text("$cycleLength days", fontWeight = FontWeight.Bold, color = BlushPrimary)
                    }
                    Slider(
                        value = cycleLength.toFloat(),
                        onValueChange = {
                            cycleLength = it.roundToInt()
                            onUpdateSettings(settings.copy(averageCycleLength = cycleLength))
                        },
                        valueRange = 21f..45f,
                        steps = 23,
                        colors = SliderDefaults.colors(thumbColor = BlushPrimary, activeTrackColor = BlushPrimary),
                        modifier = Modifier.testTag("settings_cycle_length")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Average Period Bleeding", style = MaterialTheme.typography.bodyMedium)
                        Text("$periodLength days", fontWeight = FontWeight.Bold, color = LavenderAccent)
                    }
                    Slider(
                        value = periodLength.toFloat(),
                        onValueChange = {
                            periodLength = it.roundToInt()
                            onUpdateSettings(settings.copy(averagePeriodLength = periodLength))
                        },
                        valueRange = 2f..10f,
                        steps = 7,
                        colors = SliderDefaults.colors(thumbColor = LavenderAccent, activeTrackColor = LavenderAccent),
                        modifier = Modifier.testTag("settings_period_length")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Pregnancy & Conception Mode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pregnancy Planning Mode",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Emphasizes fertile peak days, ovulation windows, and conception guidance on your cycle ring and calendar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isPregnancyMode,
                            onCheckedChange = { onTogglePregnancyMode() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = LavenderAccent),
                            modifier = Modifier.testTag("pregnancy_mode_switch")
                        )
                    }
                }
            }
        }

        // Privacy & Discretion
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Privacy & Discretion",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Discreet Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Discreet Mode",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Hides menstrual titles and names app 'Daily Journal'.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isDiscreetMode,
                            onCheckedChange = { onToggleDiscreetMode() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BlushPrimary),
                            modifier = Modifier.testTag("discreet_mode_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // PIN Lock Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "PIN Passcode Protection",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (settings.isPinEnabled) "PIN is active (4 digits)" else "Require PIN to open Bloom",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isPinEnabled,
                            onCheckedChange = { enable ->
                                if (enable) {
                                    showPinDialog = true
                                } else {
                                    onSetPin("", false)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BlushPrimary),
                            modifier = Modifier.testTag("pin_protection_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Fingerprint unlock toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Fingerprint unlock",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (settings.isPinEnabled) "Open Bloom with your fingerprint. Your PIN always works too." else "Turn on the PIN first to use fingerprint.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isBiometricEnabled && settings.isPinEnabled,
                            onCheckedChange = { enable ->
                                if (!enable) {
                                    onSetBiometric(false)
                                } else if (!settings.isPinEnabled) {
                                    Toast.makeText(context, "Please turn on the PIN first.", Toast.LENGTH_SHORT).show()
                                } else if (!BiometricHelper.isAvailable(context)) {
                                    Toast.makeText(
                                        context,
                                        "No fingerprint is set up on this phone. Add one in phone Settings, Security.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    val activity = context.findFragmentActivity()
                                    if (activity != null) {
                                        BiometricHelper.prompt(
                                            activity = activity,
                                            title = "Turn on fingerprint unlock",
                                            subtitle = "Touch the sensor to confirm",
                                            negativeText = "Cancel",
                                            onSuccess = { onSetBiometric(true) }
                                        )
                                    }
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BlushPrimary),
                            modifier = Modifier.testTag("biometric_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Hide in Recent Apps Screen (FLAG_SECURE)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Hide in Recent-Apps Screen",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Blocks app snapshots in your phone's task switcher (FLAG_SECURE) to keep your cycle details private.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isFlagSecureEnabled,
                            onCheckedChange = { onToggleFlagSecure() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BlushPrimary),
                            modifier = Modifier.testTag("flag_secure_switch")
                        )
                    }
                }
            }
        }

        // Appearance
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Appearance & Accessibility",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("LIGHT", "Blush Light", "🌸"),
                            Triple("DARK", "Calm Dark", "🌙"),
                            Triple("SYSTEM", "System", "⚙️")
                        ).forEach { (mode, label, emoji) ->
                            val isSelected = settings.themeMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) BlushPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onSetThemeMode(mode) }
                                    .testTag("theme_$mode"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$emoji $label",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "App Language",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Pair("en", "English"),
                            Pair("ta", "தமிழ்"),
                            Pair("si", "සිංහල")
                        ).forEach { (langCode, langName) ->
                            val isSelected = settings.appLanguage == langCode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) LavenderAccent else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onSetAppLanguage(langCode) }
                                    .testTag("lang_$langCode"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = langName,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // High Contrast Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "High Contrast Mode",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Enforces stronger visual borders, defined ring strokes, and deep text contrast for optimal accessibility.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.isHighContrast,
                            onCheckedChange = { onToggleHighContrast() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BlushPrimary),
                            modifier = Modifier.testTag("high_contrast_switch")
                        )
                    }
                }
            }
        }

        // Sample Data & Data Management
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Data Management",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Sample Data Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Preview Sample Data",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Preload realistic past cycles and daily logs to test all app features.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.useSampleData,
                            onCheckedChange = { onToggleSampleData(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = LavenderAccent),
                            modifier = Modifier.testTag("sample_data_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Export Data Button
                    Button(
                        onClick = { showExportDialog = true },
                        modifier = Modifier.fillMaxWidth().testTag("export_backup_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Export Local Data Backup (JSON)",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Restore Data Button
                    Button(
                        onClick = { showRestoreDialog = true },
                        modifier = Modifier.fillMaxWidth().testTag("restore_backup_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.Upload, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Restore from Backup (JSON)",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Export Doctor Report (PDF) Shortcut
                    Button(
                        onClick = {
                            val ok = DoctorReportPdfGenerator.generateAndShare(
                                context = context,
                                settings = uiState.settings,
                                pastCycles = uiState.pastCycles,
                                dailyLogs = uiState.dailyLogs
                            )
                            if (ok) {
                                Toast.makeText(context, "Opening Doctor Report PDF...", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Unable to generate PDF report", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("settings_doctor_report_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Export Doctor Report (PDF)",
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Delete All Data Button
                    Button(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Delete All Local Data",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Privacy Guarantee Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = LavenderAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Bloom Privacy Guarantee",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "All your cycle history, symptoms, and reflections are stored strictly on this device. No advertising trackers. No cloud synchronization without your explicit action.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // Set PIN Dialog
    if (showPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showPinDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Set 4-Digit Passcode",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Enter a 4-digit code to protect Bloom when opened.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinInput = it },
                        placeholder = { Text("e.g. 1234") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("pin_set_input")
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showPinDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (pinInput.length == 4) {
                                    onSetPin(pinInput, true)
                                    showPinDialog = false
                                }
                            },
                            enabled = pinInput.length == 4,
                            colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary)
                        ) {
                            Text("Save PIN")
                        }
                    }
                }
            }
        }
    }

    // Export Data Dialog
    if (showExportDialog) {
        val jsonString = remember { onExportDataJson() }
        Dialog(onDismissRequest = { showExportDialog = false }) {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Exported Data (JSON)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your complete cycle logs and preferences in readable JSON format.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        Text(
                            text = jsonString,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = { showExportDialog = false }) {
                            Text("Close")
                        }
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Bloom Data Export", jsonString)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Export copied to clipboard!", Toast.LENGTH_SHORT).show()
                                showExportDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy to Clipboard")
                        }
                    }
                }
            }
        }
    }

    // Delete All Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete All Local Data?") },
            text = { Text("This will permanently wipe all your cycle entries, daily symptoms, and custom settings from this device. This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllData()
                        showDeleteConfirmDialog = false
                        Toast.makeText(context, "All local data deleted.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Restore Backup Dialog
    if (showRestoreDialog) {
        var backupInput by remember { mutableStateOf("") }
        var isError by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showRestoreDialog = false }) {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Restore from Backup (JSON)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Paste previously exported Bloom JSON data to restore your cycle entries and preferences.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = backupInput,
                        onValueChange = {
                            backupInput = it
                            isError = false
                        },
                        placeholder = { Text("Paste JSON backup here...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .testTag("restore_backup_input"),
                        isError = isError
                    )
                    if (isError) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Invalid JSON structure. Please check and try again.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = { showRestoreDialog = false }) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                val success = onImportBackupJson(backupInput.trim())
                                if (success) {
                                    Toast.makeText(context, "Data successfully restored!", Toast.LENGTH_SHORT).show()
                                    showRestoreDialog = false
                                } else {
                                    isError = true
                                }
                            },
                            enabled = backupInput.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary)
                        ) {
                            Text("Restore Now")
                        }
                    }
                }
            }
        }
    }
}


private fun formatClock(hour: Int, minute: Int): String {
    val hour12 = if (hour % 12 == 0) 12 else hour % 12
    val suffix = if (hour < 12) "AM" else "PM"
    return "$hour12:${minute.toString().padStart(2, '0')} $suffix"
}
