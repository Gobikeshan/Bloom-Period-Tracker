package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.widget.Toast
import com.example.model.AllSymptoms
import com.example.model.FlowLevel
import com.example.model.PastCycle
import com.example.ui.BloomUiState
import com.example.ui.theme.BlushLight
import com.example.ui.theme.BlushPrimary
import com.example.ui.theme.DeepPlum
import com.example.ui.theme.LavenderAccent
import com.example.ui.theme.LavenderLight
import com.example.ui.theme.PhasePeriod
import com.example.util.DateUtils
import com.example.util.DoctorReportPdfGenerator
import java.util.UUID
import com.example.ui.components.AgeInsightsCard

@Composable
fun InsightsScreen(
    uiState: BloomUiState,
    onSavePastCycle: (PastCycle) -> Unit,
    onDeletePastCycle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddCycleDialog by remember { mutableStateOf(false) }
    var cycleToDelete by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val cycleLength = uiState.settings.averageCycleLength.coerceAtLeast(20)
    val periodLength = uiState.settings.averagePeriodLength.coerceAtLeast(2)
    val lastStart = uiState.settings.lastPeriodDate

    // Recent flow and pain logs for trend chart
    val recentFlowLogs = remember(uiState.dailyLogs) {
        uiState.dailyLogs.values
            .filter { (it.flow != null && it.flow != FlowLevel.NONE) || it.symptoms.contains("cramps") || it.symptoms.contains("back_pain") }
            .sortedByDescending { it.date }
            .take(12)
            .reversed()
    }

    // Phase symptom grouping
    val phaseSymptoms = remember(uiState.dailyLogs, lastStart, cycleLength, periodLength) {
        val map = mapOf(
            "Menstrual (Days 1–$periodLength)" to mutableMapOf<String, Int>(),
            "Follicular (Rising Energy)" to mutableMapOf<String, Int>(),
            "Ovulation (Fertile Peak)" to mutableMapOf<String, Int>(),
            "Luteal (PMS Window)" to mutableMapOf<String, Int>()
        )
        uiState.dailyLogs.values.forEach { log ->
            val phaseKey = when {
                log.flow != null && log.flow != FlowLevel.NONE -> "Menstrual (Days 1–$periodLength)"
                else -> {
                    val daysDiff = DateUtils.daysBetween(lastStart, log.date)
                    val modDay = if (daysDiff >= 0) (daysDiff % cycleLength) + 1 else 1
                    when {
                        modDay <= periodLength -> "Menstrual (Days 1–$periodLength)"
                        modDay <= (cycleLength / 2) - 2 -> "Follicular (Rising Energy)"
                        modDay <= (cycleLength / 2) + 2 -> "Ovulation (Fertile Peak)"
                        else -> "Luteal (PMS Window)"
                    }
                }
            }
            log.symptoms.forEach { sym ->
                val m = map[phaseKey]
                if (m != null) {
                    m[sym] = (m[sym] ?: 0) + 1
                }
            }
        }
        map
    }

    // Calculate symptom frequencies
    val symptomCounts = mutableMapOf<String, Int>()
    uiState.dailyLogs.values.forEach { log ->
        log.symptoms.forEach { symId ->
            symptomCounts[symId] = (symptomCounts[symId] ?: 0) + 1
        }
    }
    val topSymptoms = symptomCounts.entries.sortedByDescending { it.value }.take(5)
    val maxSymptomCount = (topSymptoms.maxOfOrNull { it.value } ?: 1).coerceAtLeast(1)

    // Calculate mood frequencies
    val moodCounts = mutableMapOf<String, Int>()
    uiState.dailyLogs.values.forEach { log ->
        log.mood?.let { m ->
            moodCounts[m] = (moodCounts[m] ?: 0) + 1
        }
    }
    val totalMoodLogs = moodCounts.values.sum().coerceAtLeast(1)

    // Regularity calculation
    val regularityText = if (uiState.pastCycles.size >= 2) {
        val lengths = uiState.pastCycles.map { it.cycleLength }
        val diff = (lengths.maxOrNull() ?: 28) - (lengths.minOrNull() ?: 28)
        when {
            diff <= 2 -> "Very Regular (±${diff}d)"
            diff <= 5 -> "Normal Variation (±${diff}d)"
            else -> "Fluctuating (±${diff}d)"
        }
    } else {
        "Awaiting more cycles"
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Cycle Insights",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Personal patterns and bodily awareness based on your logged entries.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Personalised tips by age and cycle numbers
        item {
            AgeInsightsCard(
                age = uiState.settings.age,
                cycleLength = uiState.cycleStatus.totalCycleDays,
                periodLength = uiState.settings.averagePeriodLength,
                pastCycles = uiState.pastCycles,
                compact = false
            )
        }

        // 4 Summary Metrics Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Average Cycle Length
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Avg Cycle",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${uiState.settings.averageCycleLength} days",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = BlushPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Typical range: 25-35d",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Average Period Length
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Avg Period",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${uiState.settings.averagePeriodLength} days",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = LavenderAccent
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Typical flow: 3-7d",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Regularity
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Regularity",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = regularityText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Cycles Tracked
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Recorded Cycles",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${uiState.pastCycles.size} cycles",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Doctor & Clinical Visit Report Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("doctor_report_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BlushPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Doctor & Clinical Visit Report",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Export a clean 1-page PDF of your last 6 cycles",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Need to visit your gynecologist or general practitioner? Bloom formats your cycle regularity, bleeding durations, and symptoms into a professional clinical summary you can share or print.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val ok = DoctorReportPdfGenerator.generateAndShare(
                                context = context,
                                settings = uiState.settings,
                                pastCycles = uiState.pastCycles,
                                dailyLogs = uiState.dailyLogs
                            )
                            if (ok) {
                                Toast.makeText(context, "Opening doctor report PDF...", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Unable to generate PDF report", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_doctor_report_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Export & Share Doctor Report (PDF)",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Pain and Flow Trend Chart
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pain_flow_trends_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Pain & Flow Trends",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Bleeding intensity and pain pattern across recent entries",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (recentFlowLogs.isEmpty() && uiState.pastCycles.isEmpty()) {
                        Text(
                            text = "Log daily flow levels and cramps to visualize your pain and bleeding intensity trends.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        // Legend
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(BlushPrimary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Flow Level", style = MaterialTheme.typography.labelSmall)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(LavenderAccent)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cramps / Pain", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Custom Visual Chart
                        val barColor = BlushPrimary
                        val painColor = LavenderAccent
                        val trackBg = MaterialTheme.colorScheme.surfaceVariant

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .testTag("pain_flow_canvas")
                        ) {
                            val count = recentFlowLogs.size.coerceAtLeast(6)
                            val spacing = size.width / count
                            val barWidth = (spacing * 0.55f).coerceIn(12f, 28f)
                            val maxFlowHeight = size.height - 35f

                            // Draw baseline
                            drawLine(
                                color = trackBg,
                                start = Offset(0f, size.height - 20f),
                                end = Offset(size.width, size.height - 20f),
                                strokeWidth = 2f
                            )

                            recentFlowLogs.forEachIndexed { idx, log ->
                                val x = idx * spacing + (spacing / 2f)

                                // Flow height based on level: SPOTTING=1, LIGHT=2, MEDIUM=3, HEAVY=4
                                val levelNum = when (log.flow) {
                                    FlowLevel.HEAVY -> 4
                                    FlowLevel.MEDIUM -> 3
                                    FlowLevel.LIGHT -> 2
                                    FlowLevel.SPOTTING -> 1
                                    else -> 0
                                }
                                val h = (levelNum.toFloat() / 4f) * maxFlowHeight

                                if (h > 0f) {
                                    drawRoundRect(
                                        color = barColor,
                                        topLeft = Offset(x - barWidth / 2f, size.height - 20f - h),
                                        size = Size(barWidth, h),
                                        cornerRadius = CornerRadius(8f, 8f)
                                    )
                                }

                                // Pain / cramps indicator dot
                                val hasPain = log.symptoms.contains("cramps") || log.symptoms.contains("back_pain")
                                if (hasPain) {
                                    drawCircle(
                                        color = painColor,
                                        radius = 6f,
                                        center = Offset(x, size.height - 20f - h - 14f)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (recentFlowLogs.isNotEmpty()) recentFlowLogs.first().date else "Past days",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (recentFlowLogs.isNotEmpty()) recentFlowLogs.last().date else "Today",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Common Symptoms Chart
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Most Common Symptoms",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Recorded over all your daily check-ins",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (topSymptoms.isEmpty()) {
                        Text(
                            text = "No symptoms logged yet. Check in daily on the Log tab to reveal symptom patterns over time.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            topSymptoms.forEach { (symId, count) ->
                                val sym = AllSymptoms.find { it.id == symId }
                                if (sym != null) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${sym.emoji} ${sym.label}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "$count ${if (count == 1) "time" else "times"}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        LinearProgressIndicator(
                                            progress = { count.toFloat() / maxSymptomCount },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(RoundedCornerShape(4.dp)),
                                            color = BlushPrimary,
                                            trackColor = MaterialTheme.colorScheme.primaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Symptom Patterns by Cycle Phase
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("phase_symptom_patterns_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Symptom Patterns by Cycle Phase",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Understand when bodily symptoms concentrate across your cycle",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        phaseSymptoms.forEach { (phaseTitle, symMap) ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = phaseTitle,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (phaseTitle.startsWith("Menstrual")) PhasePeriod else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))

                                    val topPhaseSyms = symMap.entries.sortedByDescending { it.value }.take(3)
                                    if (topPhaseSyms.isEmpty()) {
                                        Text(
                                            text = "No symptoms recorded in this phase yet.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                        )
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            topPhaseSyms.forEach { (symId, count) ->
                                                val s = AllSymptoms.find { it.id == symId }
                                                if (s != null) {
                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = MaterialTheme.colorScheme.surface
                                                    ) {
                                                        Text(
                                                            text = "${s.emoji} ${s.label} ($count)",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Mood Trends
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Mood Distribution",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "How you've been feeling across your recent cycles",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (moodCounts.isEmpty()) {
                        Text(
                            text = "No moods logged yet. Check in with how you feel on the Log tab.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            moodCounts.entries.sortedByDescending { it.value }.forEach { (moodName, count) ->
                                val percentage = ((count.toFloat() / totalMoodLogs) * 100).toInt()
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = moodName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "$percentage%",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = LavenderAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { percentage / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = LavenderAccent,
                                        trackColor = MaterialTheme.colorScheme.secondaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Cycle History Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Past Cycles History",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${uiState.pastCycles.size} past records",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { showAddCycleDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary),
                            modifier = Modifier.testTag("add_past_cycle_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Add Period", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (uiState.pastCycles.isEmpty()) {
                        Text(
                            text = "No previous cycles recorded yet. You can add previous periods you remember, or Bloom will automatically save cycles as time progresses.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            uiState.pastCycles.forEach { cycle ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "Cycle: ${DateUtils.formatDisplay(cycle.startDate)}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${cycle.cycleLength} days long • ${cycle.periodLength} days flow",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        IconButton(
                                            onClick = { cycleToDelete = cycle.id },
                                            modifier = Modifier.size(32.dp).testTag("delete_cycle_${cycle.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Medical Disclaimer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = LavenderAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Gentle Note: Bloom's cycle forecasts and fertility windows are estimations based on recorded cycle averages. They are intended for personal wellness awareness and planning, not medical diagnosis or contraception.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // Add Past Cycle Dialog
    if (showAddCycleDialog) {
        var startDate by remember { mutableStateOf(DateUtils.addDays(DateUtils.today(), -35)) }
        var cycleDays by remember { mutableStateOf("28") }
        var periodDays by remember { mutableStateOf("5") }

        Dialog(onDismissRequest = { showAddCycleDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Add Past Period",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Start Date (YYYY-MM-DD)", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Cycle Length (Days)", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(
                        value = cycleDays,
                        onValueChange = { cycleDays = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Period Bleeding (Days)", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(
                        value = periodDays,
                        onValueChange = { periodDays = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAddCycleDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val cDays = cycleDays.toIntOrNull() ?: 28
                                val pDays = periodDays.toIntOrNull() ?: 5
                                onSavePastCycle(
                                    PastCycle(
                                        id = "cycle_${UUID.randomUUID().toString().take(6)}",
                                        startDate = startDate.trim(),
                                        periodLength = pDays,
                                        cycleLength = cDays
                                    )
                                )
                                showAddCycleDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary)
                        ) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (cycleToDelete != null) {
        AlertDialog(
            onDismissRequest = { cycleToDelete = null },
            title = { Text("Delete Cycle Record?") },
            text = { Text("Are you sure you want to remove this historical cycle from your insights?") },
            confirmButton = {
                Button(
                    onClick = {
                        cycleToDelete?.let { onDeletePastCycle(it) }
                        cycleToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { cycleToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
