package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AllSymptoms
import com.example.model.ChecklistItem
import com.example.model.DailyLog
import com.example.model.EducationArticle
import com.example.model.FlowLevel
import com.example.model.PastCycle
import com.example.model.UserSettings
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class BloomRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("bloom_preferences", Context.MODE_PRIVATE)

    // Default checklist items
    private val defaultChecklist = listOf(
        ChecklistItem("c_1", "Pads, tampons or menstrual cup stocked", isChecked = true),
        ChecklistItem("c_2", "Pain relief (Ibuprofen / heat patches)", isChecked = false),
        ChecklistItem("c_3", "Heating pad or hot water bottle ready", isChecked = true),
        ChecklistItem("c_4", "Comfortable spare underwear & clothes", isChecked = false),
        ChecklistItem("c_5", "Favorite snacks & chamomile tea", isChecked = true)
    )

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private val _dailyLogs = MutableStateFlow(loadDailyLogs())
    val dailyLogs: StateFlow<Map<String, DailyLog>> = _dailyLogs.asStateFlow()

    private val _pastCycles = MutableStateFlow(loadPastCycles())
    val pastCycles: StateFlow<List<PastCycle>> = _pastCycles.asStateFlow()

    private val _checklist = MutableStateFlow(loadChecklist())
    val checklist: StateFlow<List<ChecklistItem>> = _checklist.asStateFlow()

    // Educational articles
    val articles: List<EducationArticle> = listOf(
        EducationArticle(
            id = "art_phases",
            title = "The 4 Cycle Phases Explained",
            category = "Cycle Wisdom",
            readTime = "4 min read",
            summary = "How estrogen and progesterone choreograph your energy, mood, and body across each phase.",
            iconEmoji = "🌸",
            fullContent = """
                Your menstrual cycle is much more than just your period. It is an internal seasonal rhythm guided by rising and falling hormones.
                
                1. Menstrual Phase (Inner Winter - Days 1 to 5)
                • Progesterone and estrogen are at their lowest baseline.
                • Energy naturally turns inward. Your uterus sheds its lining.
                • Self-care: Prioritize slow mornings, warm nourishing stews, magnesium to ease cramps, and cozy sleep.
                
                2. Follicular Phase (Inner Spring - Days 6 to 13)
                • Pituitary gland releases FSH; follicles develop and estrogen rises.
                • Energy, mental sharpness, and optimism elevate.
                • Self-care: Ideal time to start new habits, brainstorm creative projects, and do cardio or strength workouts.
                
                3. Ovulatory Phase (Inner Summer - Days 14 to 16)
                • A sudden surge of Luteinizing Hormone (LH) triggers the release of an egg.
                • You are at your most magnetic and communicative.
                • Self-care: Stay hydrated, connect socially, and enjoy vibrant antioxidant-packed meals.
                
                4. Luteal Phase (Inner Autumn - Days 17 to 28)
                • The ruptured follicle becomes the corpus luteum, secreting progesterone to nourish the uterine lining.
                • Metabolic rate slightly rises, which is why appetite and cravings for carbs increase.
                • Self-care: Swap HIIT for restorative yoga, eat roasted root vegetables, and build boundaries.
            """.trimIndent()
        ),
        EducationArticle(
            id = "art_pms",
            title = "PMS & PMDD: Finding Real Relief",
            category = "Comfort & Care",
            readTime = "5 min read",
            summary = "Understanding why mood shifts and bloating happen before your period, and kind ways to soothe them.",
            iconEmoji = "🌙",
            fullContent = """
                Premenstrual symptoms affect over 85% of menstruating people. Understanding what triggers them removes guilt and self-blame.
                
                Why Moods Fluctuate:
                In the late luteal phase, progesterone peaks and then abruptly drops if pregnancy does not occur. This rapid drop directly influences serotonin, dopamine, and GABA in the brain.
                
                Gentle Evidence-Based Relief:
                • Magnesium Glycinate: Helps relax uterine smooth muscle, reducing cramps and calming nervous tension.
                • Vitamin B6: Assists in synthesizing serotonin and dopamine to stabilize pre-period weepiness or irritability.
                • Complex Carbohydrates: Sweet potatoes, oats, and quinoa sustain blood sugar levels and curb sudden intense cravings.
                • Epsom Salt Baths: Warm magnesium baths relax tight pelvic floors and lower back soreness.
                
                When is it PMDD?
                Premenstrual Dysphoric Disorder (PMDD) involves severe, debilitating emotional distress (severe depression, sudden rage, overwhelming anxiety) in the 7-10 days before bleeding that disappears shortly after flow begins. If you feel incapacitated each month, know that effective medical support exists—speak openly with your doctor.
            """.trimIndent()
        ),
        EducationArticle(
            id = "art_doctor",
            title = "When to Speak with a Doctor",
            category = "Health Advocacy",
            readTime = "3 min read",
            summary = "Clear, non-judgmental guidance on heavy bleeding, extreme pain, or missed cycles.",
            iconEmoji = "🩺",
            fullContent = """
                Period pain is common, but excruciating pain that disrupts your life is not 'just something you have to live with.' You deserve compassionate, proactive healthcare.
                
                Key Signs to Discuss With a Gynecologist:
                • Heavy Bleeding: Soaking through a super pad or tampon every hour for two or more consecutive hours, or passing blood clots larger than a quarter.
                • Debilitating Pain: Severe pelvic or abdominal pain not relieved by standard over-the-counter pain relievers, or pain during urination or bowel movements during your period.
                • Cycle Irregularity: Cycles that consistently arrive sooner than 21 days or longer than 38 days apart.
                • Missed Periods: Three or more missed periods without pregnancy or breastfeeding.
                • Intermenstrual Bleeding: Bleeding or spotting between periods or after intercourse.
                
                Tips for Your Appointment:
                Export your Bloom cycle and symptom logs to show your doctor concrete data over 2 to 3 months. Having recorded dates, pain severity, and flow levels gives your healthcare provider invaluable clarity.
            """.trimIndent()
        ),
        EducationArticle(
            id = "art_nutrition",
            title = "Cycle Syncing & Seed Cycling",
            category = "Nourishment",
            readTime = "4 min read",
            summary = "Fueling your body according to hormonal needs throughout your monthly cycle.",
            iconEmoji = "🥑",
            fullContent = """
                Nutritional needs evolve across your cycle as your metabolic rate and hormonal balance shift.
                
                Phase-by-Phase Nutrition:
                • Menstrual: Replenish iron and minerals. Bone broth, lentils, grass-fed beef, spinach, dark chocolate, and ginger tea.
                • Follicular: Light, fresh, probiotic foods. Kimchi, sauerkraut, sprouted grains, berries, and lean proteins.
                • Ovulation: Liver-supporting brassicas. Broccoli, cauliflower, citrus fruits, and zinc-rich pumpkin seeds.
                • Luteal: Sustained energy and magnesium. Brown rice, sweet potatoes, walnuts, avocados, and herbal peppermint tea.
                
                Seed Cycling 101:
                • Days 1 to 14 (Follicular): 1 tbsp raw ground flaxseeds + 1 tbsp pumpkin seeds daily (supports healthy estrogen metabolism).
                • Days 15 to 28 (Luteal): 1 tbsp raw ground sunflower seeds + 1 tbsp sesame seeds daily (supports healthy progesterone production).
            """.trimIndent()
        ),
        EducationArticle(
            id = "art_fertile",
            title = "Fertility & Ovulation Signals",
            category = "Body Literacy",
            readTime = "3 min read",
            summary = "How to listen to your body's subtle changes in temperature, energy, and cervical fluid.",
            iconEmoji = "✨",
            fullContent = """
                Your body communicates its fertility status naturally every cycle:
                
                The 6-Day Fertile Window:
                Sperm can survive in fertile cervical mucus for up to 5 days, whereas an unfertilized egg lives for 12 to 24 hours. Thus, the 5 days before ovulation plus ovulation day itself form your fertile window.
                
                Key Natural Biomarkers:
                • Cervical Fluid: Transitions from dry/sticky after your period, to creamy, to clear and stretchy like raw egg-whites around ovulation peak.
                • Basal Body Temperature (BBT): Remains slightly lower in the follicular phase, then rises by approximately 0.5°F (0.3°C) after ovulation due to thermogenic progesterone.
                • Mittelschmerz: A mild, brief one-sided twinge or ache in the lower abdomen when an ovary releases an egg.
                • Heightened Senses: Many women notice sharper smell and taste and higher libido around their fertile peak.
            """.trimIndent()
        )
    )

    fun updateSettings(newSettings: UserSettings) {
        _settings.value = newSettings
        saveSettings(newSettings)
    }

    fun completeOnboarding(
        name: String,
        cycleLength: Int,
        periodLength: Int,
        lastPeriodDate: String,
        reminderDays: Int,
        dailyReminder: Boolean
    ) {
        val current = _settings.value
        val updated = current.copy(
            name = if (name.isNotBlank()) name else "Friend",
            averageCycleLength = cycleLength,
            averagePeriodLength = periodLength,
            lastPeriodDate = lastPeriodDate,
            reminderDaysBefore = reminderDays,
            dailyReminder = dailyReminder,
            hasCompletedOnboarding = true
        )
        updateSettings(updated)

        // If a last period was provided, ensure it's logged
        if (lastPeriodDate.isNotBlank()) {
            saveDailyLog(
                DailyLog(
                    date = lastPeriodDate,
                    isPeriod = true,
                    flow = FlowLevel.MEDIUM,
                    notes = "Period started"
                )
            )
        }
    }

    fun updateCycleSettings(
        name: String,
        cycleLength: Int,
        periodLength: Int,
        lastPeriodDate: String,
        reminderDays: Int,
        dailyReminder: Boolean
    ) {
        updateSettings(
            _settings.value.copy(
                name = if (name.isNotBlank()) name else "Friend",
                averageCycleLength = cycleLength,
                averagePeriodLength = periodLength,
                lastPeriodDate = lastPeriodDate,
                reminderDaysBefore = reminderDays,
                dailyReminder = dailyReminder
            )
        )
    }

    fun markCoachMarksSeen() {
        val current = _settings.value
        updateSettings(current.copy(hasSeenCoachMarks = true))
    }

    fun toggleDiscreetMode() {
        val current = _settings.value
        updateSettings(current.copy(isDiscreetMode = !current.isDiscreetMode))
    }

    fun setThemeMode(mode: String) {
        val current = _settings.value
        updateSettings(current.copy(themeMode = mode))
    }

    fun setPin(pin: String, enabled: Boolean) {
        val current = _settings.value
        updateSettings(current.copy(pinCode = pin, isPinEnabled = enabled))
    }

    fun saveDailyLog(log: DailyLog) {
        val updated = _dailyLogs.value.toMutableMap()
        updated[log.date] = log
        _dailyLogs.value = updated
        persistDailyLogs(updated)

        // If marked as period, update lastPeriodDate if newer
        if (log.isPeriod && log.flow != FlowLevel.NONE) {
            val currentLast = _settings.value.lastPeriodDate
            if (currentLast.isBlank() || log.date > currentLast) {
                updateSettings(_settings.value.copy(lastPeriodDate = log.date))
            }
        }
    }

    fun getDailyLog(date: String): DailyLog {
        return _dailyLogs.value[date] ?: DailyLog(date = date)
    }

    fun savePastCycle(cycle: PastCycle) {
        val list = _pastCycles.value.filter { it.id != cycle.id }.toMutableList()
        list.add(0, cycle)
        list.sortByDescending { it.startDate }
        _pastCycles.value = list
        persistPastCycles(list)
    }

    fun deletePastCycle(id: String) {
        val list = _pastCycles.value.filter { it.id != id }
        _pastCycles.value = list
        persistPastCycles(list)
    }

    fun toggleChecklistItem(id: String) {
        val list = _checklist.value.map { item ->
            if (item.id == id) item.copy(isChecked = !item.isChecked) else item
        }
        _checklist.value = list
        persistChecklist(list)
    }

    fun addCustomChecklistItem(title: String) {
        if (title.isBlank()) return
        val newItem = ChecklistItem(
            id = "c_${UUID.randomUUID().toString().take(6)}",
            title = title,
            isChecked = false,
            isCustom = true
        )
        val list = _checklist.value + newItem
        _checklist.value = list
        persistChecklist(list)
    }

    fun removeChecklistItem(id: String) {
        val list = _checklist.value.filter { it.id != id }
        _checklist.value = list
        persistChecklist(list)
    }

    fun resetChecklist() {
        _checklist.value = defaultChecklist
        persistChecklist(defaultChecklist)
    }

    fun toggleSampleData(enable: Boolean) {
        if (enable) {
            loadSampleData()
        } else {
            clearData(keepOnboarding = true)
        }
    }

    fun clearData(keepOnboarding: Boolean = false) {
        val currentSettings = _settings.value
        val newSettings = if (keepOnboarding) {
            currentSettings.copy(
                useSampleData = false,
                lastPeriodDate = DateUtils.addDays(DateUtils.today(), -7)
            )
        } else {
            UserSettings()
        }
        _settings.value = newSettings
        saveSettings(newSettings)

        _dailyLogs.value = emptyMap()
        persistDailyLogs(emptyMap())

        _pastCycles.value = emptyList()
        persistPastCycles(emptyList())

        _checklist.value = defaultChecklist
        persistChecklist(defaultChecklist)
    }

    fun exportDataJson(): String {
        val root = JSONObject()
        root.put("app", "Bloom")
        root.put("exportedAt", DateUtils.today())

        val settingsObj = JSONObject()
        val s = _settings.value
        settingsObj.put("name", s.name)
        settingsObj.put("averageCycleLength", s.averageCycleLength)
        settingsObj.put("averagePeriodLength", s.averagePeriodLength)
        settingsObj.put("lastPeriodDate", s.lastPeriodDate)
        root.put("settings", settingsObj)

        val logsArray = JSONArray()
        _dailyLogs.value.values.forEach { log ->
            val obj = JSONObject()
            obj.put("date", log.date)
            obj.put("isPeriod", log.isPeriod)
            obj.put("flow", log.flow.name)
            obj.put("symptoms", JSONArray(log.symptoms))
            obj.put("mood", log.mood ?: "")
            obj.put("sleepHours", log.sleepHours.toDouble())
            obj.put("waterGlasses", log.waterGlasses)
            obj.put("energy", log.energy ?: "")
            obj.put("notes", log.notes)
            logsArray.put(obj)
        }
        root.put("dailyLogs", logsArray)

        val cyclesArray = JSONArray()
        _pastCycles.value.forEach { cycle ->
            val obj = JSONObject()
            obj.put("id", cycle.id)
            obj.put("startDate", cycle.startDate)
            obj.put("endDate", cycle.endDate ?: "")
            obj.put("periodLength", cycle.periodLength)
            obj.put("cycleLength", cycle.cycleLength)
            cyclesArray.put(obj)
        }
        root.put("pastCycles", cyclesArray)

        return root.toString(2)
    }

    private fun loadSampleData() {
        val today = DateUtils.today()
        val lastStart = DateUtils.addDays(today, -13) // Currently Day 14 (Ovulation)

        val updatedSettings = _settings.value.copy(
            name = if (_settings.value.name == "Friend") "Elena" else _settings.value.name,
            averageCycleLength = 28,
            averagePeriodLength = 5,
            lastPeriodDate = lastStart,
            hasCompletedOnboarding = true,
            hasSeenCoachMarks = true,
            useSampleData = true
        )
        updateSettings(updatedSettings)

        // Past completed cycles
        val sampleCycles = listOf(
            PastCycle("c_prev_1", DateUtils.addDays(lastStart, -28), DateUtils.addDays(lastStart, -23), 5, 28),
            PastCycle("c_prev_2", DateUtils.addDays(lastStart, -57), DateUtils.addDays(lastStart, -52), 5, 29),
            PastCycle("c_prev_3", DateUtils.addDays(lastStart, -84), DateUtils.addDays(lastStart, -80), 4, 27)
        )
        _pastCycles.value = sampleCycles
        persistPastCycles(sampleCycles)

        // Sample logs for recent days
        val sampleLogs = mutableMapOf<String, DailyLog>()
        // Day 1 to 5: Period days
        sampleLogs[lastStart] = DailyLog(
            date = lastStart,
            isPeriod = true,
            flow = FlowLevel.MEDIUM,
            symptoms = listOf("cramps", "fatigue"),
            mood = "calm",
            sleepHours = 8f,
            waterGlasses = 6,
            energy = "Low",
            notes = "Period arrived gently. Warm tea and heating pad helped a lot."
        )
        sampleLogs[DateUtils.addDays(lastStart, 1)] = DailyLog(
            date = DateUtils.addDays(lastStart, 1),
            isPeriod = true,
            flow = FlowLevel.HEAVY,
            symptoms = listOf("cramps", "bloating"),
            mood = "sensitive",
            sleepHours = 7f,
            waterGlasses = 7,
            energy = "Low",
            notes = "Cramps in the morning, rested on the couch."
        )
        sampleLogs[DateUtils.addDays(lastStart, 2)] = DailyLog(
            date = DateUtils.addDays(lastStart, 2),
            isPeriod = true,
            flow = FlowLevel.MEDIUM,
            symptoms = listOf("headache"),
            mood = "calm",
            sleepHours = 8.5f,
            waterGlasses = 8,
            energy = "Medium",
            notes = "Feeling much better today."
        )
        sampleLogs[DateUtils.addDays(lastStart, 4)] = DailyLog(
            date = DateUtils.addDays(lastStart, 4),
            isPeriod = true,
            flow = FlowLevel.LIGHT,
            symptoms = emptyList(),
            mood = "happy",
            sleepHours = 8f,
            waterGlasses = 7,
            energy = "Medium",
            notes = "Period tapering off."
        )
        // Follicular / Ovulation days
        sampleLogs[DateUtils.addDays(lastStart, 8)] = DailyLog(
            date = DateUtils.addDays(lastStart, 8),
            isPeriod = false,
            flow = FlowLevel.NONE,
            symptoms = emptyList(),
            mood = "energetic",
            sleepHours = 7.5f,
            waterGlasses = 8,
            energy = "High",
            notes = "Had a great morning run and felt upbeat!"
        )
        sampleLogs[today] = DailyLog(
            date = today,
            isPeriod = false,
            flow = FlowLevel.NONE,
            symptoms = listOf("cravings"),
            mood = "happy",
            sleepHours = 8f,
            waterGlasses = 5,
            energy = "High",
            notes = "Skin glowing today, craving fresh fruit."
        )

        _dailyLogs.value = sampleLogs
        persistDailyLogs(sampleLogs)
    }

    private fun loadSettings(): UserSettings {
        return UserSettings(
            name = prefs.getString("user_name", "Friend") ?: "Friend",
            averageCycleLength = prefs.getInt("cycle_length", 28),
            averagePeriodLength = prefs.getInt("period_length", 5),
            lastPeriodDate = prefs.getString("last_period_date", "") ?: "",
            reminderDaysBefore = prefs.getInt("reminder_days", 3),
            dailyReminder = prefs.getBoolean("daily_reminder", true),
            themeMode = prefs.getString("theme_mode", "LIGHT") ?: "LIGHT",
            pinCode = prefs.getString("pin_code", "") ?: "",
            isPinEnabled = prefs.getBoolean("pin_enabled", false),
            isDiscreetMode = prefs.getBoolean("discreet_mode", false),
            hasCompletedOnboarding = prefs.getBoolean("onboarding_complete", false),
            hasSeenCoachMarks = prefs.getBoolean("coach_marks_seen", false),
            useSampleData = prefs.getBoolean("sample_data", false)
        )
    }

    private fun saveSettings(s: UserSettings) {
        prefs.edit()
            .putString("user_name", s.name)
            .putInt("cycle_length", s.averageCycleLength)
            .putInt("period_length", s.averagePeriodLength)
            .putString("last_period_date", s.lastPeriodDate)
            .putInt("reminder_days", s.reminderDaysBefore)
            .putBoolean("daily_reminder", s.dailyReminder)
            .putString("theme_mode", s.themeMode)
            .putString("pin_code", s.pinCode)
            .putBoolean("pin_enabled", s.isPinEnabled)
            .putBoolean("discreet_mode", s.isDiscreetMode)
            .putBoolean("onboarding_complete", s.hasCompletedOnboarding)
            .putBoolean("coach_marks_seen", s.hasSeenCoachMarks)
            .putBoolean("sample_data", s.useSampleData)
            .apply()
    }

    private fun loadDailyLogs(): Map<String, DailyLog> {
        val raw = prefs.getString("daily_logs_json", null) ?: return emptyMap()
        val result = mutableMapOf<String, DailyLog>()
        try {
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val date = obj.getString("date")
                val isPeriod = obj.optBoolean("isPeriod", false)
                val flowStr = obj.optString("flow", "NONE")
                val flow = try { FlowLevel.valueOf(flowStr) } catch (e: Exception) { FlowLevel.NONE }
                val sympArray = obj.optJSONArray("symptoms") ?: JSONArray()
                val symptoms = mutableListOf<String>()
                for (j in 0 until sympArray.length()) {
                    symptoms.add(sympArray.getString(j))
                }
                val mood = if (obj.has("mood") && !obj.isNull("mood")) obj.getString("mood") else null
                val sleep = obj.optDouble("sleepHours", 7.5).toFloat()
                val water = obj.optInt("waterGlasses", 4)
                val energy = if (obj.has("energy") && !obj.isNull("energy")) obj.getString("energy") else null
                val notes = obj.optString("notes", "")

                result[date] = DailyLog(
                    date = date,
                    isPeriod = isPeriod,
                    flow = flow,
                    symptoms = symptoms,
                    mood = mood,
                    sleepHours = sleep,
                    waterGlasses = water,
                    energy = energy,
                    notes = notes
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    private fun persistDailyLogs(map: Map<String, DailyLog>) {
        try {
            val jsonArray = JSONArray()
            map.values.forEach { log ->
                val obj = JSONObject()
                obj.put("date", log.date)
                obj.put("isPeriod", log.isPeriod)
                obj.put("flow", log.flow.name)
                obj.put("symptoms", JSONArray(log.symptoms))
                obj.put("mood", log.mood ?: "")
                obj.put("sleepHours", log.sleepHours.toDouble())
                obj.put("waterGlasses", log.waterGlasses)
                obj.put("energy", log.energy ?: "")
                obj.put("notes", log.notes)
                jsonArray.put(obj)
            }
            prefs.edit().putString("daily_logs_json", jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadPastCycles(): List<PastCycle> {
        val raw = prefs.getString("past_cycles_json", null) ?: return emptyList()
        val result = mutableListOf<PastCycle>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    PastCycle(
                        id = obj.getString("id"),
                        startDate = obj.getString("startDate"),
                        endDate = if (obj.has("endDate") && !obj.isNull("endDate")) obj.getString("endDate") else null,
                        periodLength = obj.optInt("periodLength", 5),
                        cycleLength = obj.optInt("cycleLength", 28)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    private fun persistPastCycles(list: List<PastCycle>) {
        try {
            val arr = JSONArray()
            list.forEach { cycle ->
                val obj = JSONObject()
                obj.put("id", cycle.id)
                obj.put("startDate", cycle.startDate)
                obj.put("endDate", cycle.endDate ?: "")
                obj.put("periodLength", cycle.periodLength)
                obj.put("cycleLength", cycle.cycleLength)
                arr.put(obj)
            }
            prefs.edit().putString("past_cycles_json", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadChecklist(): List<ChecklistItem> {
        val raw = prefs.getString("checklist_json", null) ?: return defaultChecklist
        val result = mutableListOf<ChecklistItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    ChecklistItem(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        isChecked = obj.optBoolean("isChecked", false),
                        isCustom = obj.optBoolean("isCustom", false)
                    )
                )
            }
        } catch (e: Exception) {
            return defaultChecklist
        }
        return if (result.isEmpty()) defaultChecklist else result
    }

    private fun persistChecklist(list: List<ChecklistItem>) {
        try {
            val arr = JSONArray()
            list.forEach { item ->
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("title", item.title)
                obj.put("isChecked", item.isChecked)
                obj.put("isCustom", item.isCustom)
                arr.put(obj)
            }
            prefs.edit().putString("checklist_json", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
