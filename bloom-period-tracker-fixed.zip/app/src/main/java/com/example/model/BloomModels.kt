package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.PhaseFollicular
import com.example.ui.theme.PhaseFollicularBg
import com.example.ui.theme.PhaseLuteal
import com.example.ui.theme.PhaseLutealBg
import com.example.ui.theme.PhaseOvulation
import com.example.ui.theme.PhaseOvulationBg
import com.example.ui.theme.PhasePeriod
import com.example.ui.theme.PhasePeriodBg

enum class CyclePhase(
    val title: String,
    val subtitle: String,
    val color: Color,
    val bgColor: Color,
    val iconEmoji: String
) {
    PERIOD(
        title = "Period",
        subtitle = "Rest & gentle nourishment",
        color = PhasePeriod,
        bgColor = PhasePeriodBg,
        iconEmoji = "🌸"
    ),
    FOLLICULAR(
        title = "Follicular",
        subtitle = "Rising energy & creativity",
        color = PhaseFollicular,
        bgColor = PhaseFollicularBg,
        iconEmoji = "🌱"
    ),
    OVULATION(
        title = "Ovulation",
        subtitle = "Peak vitality & confidence",
        color = PhaseOvulation,
        bgColor = PhaseOvulationBg,
        iconEmoji = "✨"
    ),
    LUTEAL(
        title = "Luteal",
        subtitle = "Wind down & cozy comfort",
        color = PhaseLuteal,
        bgColor = PhaseLutealBg,
        iconEmoji = "🌙"
    )
}

enum class FlowLevel(val label: String, val icon: String) {
    NONE("None", "—"),
    SPOTTING("Spotting", "💧"),
    LIGHT("Light", "💧"),
    MEDIUM("Medium", "🩸"),
    HEAVY("Heavy", "🩸🩸")
}

data class SymptomItem(
    val id: String,
    val label: String,
    val emoji: String
)

val AllSymptoms = listOf(
    SymptomItem("cramps", "Cramps", "⚡"),
    SymptomItem("headache", "Headache", "🤕"),
    SymptomItem("bloating", "Bloating", "🎈"),
    SymptomItem("back_pain", "Back pain", "🦴"),
    SymptomItem("acne", "Acne", "✨"),
    SymptomItem("fatigue", "Fatigue", "😴"),
    SymptomItem("cravings", "Cravings", "🍫"),
    SymptomItem("tender_breasts", "Tender breasts", "🌸"),
    SymptomItem("mood_swings", "Mood shifts", "🌊"),
    SymptomItem("nausea", "Nausea", "🫧")
)

data class MoodItem(
    val id: String,
    val label: String,
    val emoji: String
)

val AllMoods = listOf(
    MoodItem("happy", "Happy", "😊"),
    MoodItem("calm", "Calm", "😌"),
    MoodItem("energetic", "Energetic", "⚡"),
    MoodItem("anxious", "Anxious", "😟"),
    MoodItem("sad", "Sad", "😢"),
    MoodItem("irritable", "Irritable", "😤"),
    MoodItem("sensitive", "Sensitive", "🥺")
)

data class DailyLog(
    val date: String, // "YYYY-MM-DD"
    val isPeriod: Boolean = false,
    val flow: FlowLevel = FlowLevel.NONE,
    val symptoms: List<String> = emptyList(),
    val mood: String? = null,
    val sleepHours: Float = 7.5f,
    val waterGlasses: Int = 4,
    val energy: String? = "Medium",
    val notes: String = ""
)

data class PastCycle(
    val id: String,
    val startDate: String, // "YYYY-MM-DD"
    val endDate: String? = null,
    val periodLength: Int = 5,
    val cycleLength: Int = 28
)

data class ChecklistItem(
    val id: String,
    val title: String,
    val isChecked: Boolean = false,
    val isCustom: Boolean = false
)

data class CycleStatus(
    val cycleDay: Int,
    val totalCycleDays: Int,
    val phase: CyclePhase,
    val daysUntilNextPeriod: Int,
    val isLate: Boolean,
    val lateDays: Int,
    val nextPeriodDate: String,
    val ovulationDate: String,
    val fertileStart: String,
    val fertileEnd: String,
    val conceptionChance: String,
    val dailyTipCategory: String,
    val dailyTipTitle: String,
    val dailyTipText: String
)

data class UserSettings(
    val name: String = "Friend",
    val averageCycleLength: Int = 28,
    val averagePeriodLength: Int = 5,
    val lastPeriodDate: String = "",
    val reminderDaysBefore: Int = 3,
    val dailyReminder: Boolean = true,
    val themeMode: String = "LIGHT", // "LIGHT", "DARK", "SYSTEM"
    val pinCode: String = "",
    val isPinEnabled: Boolean = false,
    val isDiscreetMode: Boolean = false,
    val hasCompletedOnboarding: Boolean = false,
    val hasSeenCoachMarks: Boolean = false,
    val useSampleData: Boolean = false
)

data class EducationArticle(
    val id: String,
    val title: String,
    val category: String,
    val readTime: String,
    val summary: String,
    val fullContent: String,
    val iconEmoji: String
)
