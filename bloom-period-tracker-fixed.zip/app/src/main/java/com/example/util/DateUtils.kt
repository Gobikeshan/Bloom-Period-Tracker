package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("MMM d, yyyy", Locale.US)
    private val shortMonthDay = SimpleDateFormat("MMM d", Locale.US)
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.US)
    private val dayOfWeekFormat = SimpleDateFormat("EEE", Locale.US)

    @Synchronized
    fun today(): String {
        return isoFormat.format(Date())
    }

    @Synchronized
    fun parseDate(dateStr: String): Date? {
        return try {
            isoFormat.parse(dateStr)
        } catch (e: Exception) {
            null
        }
    }

    @Synchronized
    fun formatDate(date: Date): String {
        return isoFormat.format(date)
    }

    @Synchronized
    fun formatDisplay(dateStr: String): String {
        val date = parseDate(dateStr) ?: return dateStr
        return displayFormat.format(date)
    }

    @Synchronized
    fun formatShort(dateStr: String): String {
        val date = parseDate(dateStr) ?: return dateStr
        return shortMonthDay.format(date)
    }

    @Synchronized
    fun formatMonthYear(year: Int, month: Int): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return monthYearFormat.format(cal.time)
    }

    @Synchronized
    fun addDays(dateStr: String, days: Int): String {
        val date = parseDate(dateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_MONTH, days)
        return isoFormat.format(cal.time)
    }

    @Synchronized
    fun daysBetween(fromStr: String, toStr: String): Int {
        val fromDate = parseDate(fromStr) ?: return 0
        val toDate = parseDate(toStr) ?: return 0
        val diffMillis = toDate.time - fromDate.time
        return Math.round(diffMillis / 86_400_000.0).toInt()
    }

    fun getYear(dateStr: String): Int {
        val date = parseDate(dateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        return cal.get(Calendar.YEAR)
    }

    fun getMonth(dateStr: String): Int {
        val date = parseDate(dateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        return cal.get(Calendar.MONTH) + 1
    }

    fun getDay(dateStr: String): Int {
        val date = parseDate(dateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        return cal.get(Calendar.DAY_OF_MONTH)
    }

    fun getDaysInMonth(year: Int, month: Int): Int {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    /**
     * Returns 0 for Sunday, 1 for Monday, etc.
     */
    fun getFirstDayOfWeek(year: Int, month: Int): Int {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sunday, 6 = Saturday
    }

    fun buildDate(year: Int, month: Int, day: Int): String {
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
    }
}
