package com.example.util

import com.example.model.CyclePhase
import com.example.model.CycleStatus
import com.example.model.PastCycle
import kotlin.math.roundToInt

object CycleCalculator {

    fun calculateCycleStatus(
        lastPeriodDate: String,
        configuredCycleLength: Int = 28,
        configuredPeriodLength: Int = 5,
        pastCycles: List<PastCycle> = emptyList(),
        today: String = DateUtils.today()
    ): CycleStatus {
        val effectiveCycleLength = if (pastCycles.isNotEmpty()) {
            val validCycles = pastCycles.filter { it.cycleLength in 20..50 }
            if (validCycles.isNotEmpty()) {
                validCycles.map { it.cycleLength }.average().roundToInt()
            } else {
                configuredCycleLength
            }
        } else {
            configuredCycleLength
        }

        val effectivePeriodLength = if (pastCycles.isNotEmpty()) {
            val validPeriods = pastCycles.filter { it.periodLength in 2..10 }
            if (validPeriods.isNotEmpty()) {
                validPeriods.map { it.periodLength }.average().roundToInt()
            } else {
                configuredPeriodLength
            }
        } else {
            configuredPeriodLength
        }

        val baseDate = if (lastPeriodDate.isBlank()) {
            DateUtils.addDays(today, -10)
        } else {
            lastPeriodDate
        }

        val daysSinceStart = DateUtils.daysBetween(baseDate, today)
        val cycleDay = (daysSinceStart + 1).coerceAtLeast(1)

        val nextPeriodDate = DateUtils.addDays(baseDate, effectiveCycleLength)
        val ovulationDayNumber = (effectiveCycleLength - 14).coerceAtLeast(effectivePeriodLength + 1)
        val ovulationDate = DateUtils.addDays(baseDate, ovulationDayNumber - 1)
        val fertileStart = DateUtils.addDays(ovulationDate, -5)
        val fertileEnd = DateUtils.addDays(ovulationDate, 1)

        val daysUntil = DateUtils.daysBetween(today, nextPeriodDate)
        val isLate = daysUntil < 0
        val lateDays = if (isLate) -daysUntil else 0

        val (phase, conceptionChance, tipCategory, tipTitle, tipText) = when {
            cycleDay <= effectivePeriodLength -> {
                Tuple5(
                    CyclePhase.PERIOD,
                    "Very Low",
                    "Food & Rest",
                    "Nourish your inner winter",
                    "Iron and magnesium-rich treats like warm dark chocolate and leafy greens help soothe muscle tension. Give yourself grace to rest."
                )
            }
            cycleDay < (ovulationDayNumber - 5) -> {
                Tuple5(
                    CyclePhase.FOLLICULAR,
                    "Medium",
                    "Creativity & Energy",
                    "Riding the estrogen wave",
                    "Your mental clarity and optimism are picking up. Wonderful time for starting new projects, lively conversations, or learning something fun."
                )
            }
            cycleDay <= ovulationDayNumber + 1 -> {
                val isPeak = cycleDay == ovulationDayNumber
                Tuple5(
                    CyclePhase.OVULATION,
                    if (isPeak) "Peak (High)" else "High",
                    "Vitality & Hydration",
                    if (isPeak) "Peak radiance today" else "Approaching ovulation peak",
                    "Estrogen and LH peak around now! Keep hydrated with lemon or cucumber water, and enjoy your natural surge in energy and confidence."
                )
            }
            cycleDay <= effectiveCycleLength -> {
                Tuple5(
                    CyclePhase.LUTEAL,
                    "Low",
                    "Self-Care & Calm",
                    "Nurture your calm space",
                    "Progesterone is active. Balance cravings with complex carbs like roasted sweet potatoes, swap intense workouts for yoga, and wind down early."
                )
            }
            else -> {
                Tuple5(
                    CyclePhase.LUTEAL,
                    "Low",
                    "Patience & Comfort",
                    "Cycle is lingering a bit",
                    "Slight shifts from stress, travel, or seasons are completely natural. Take slow deep breaths, hydrate well, and take it easy."
                )
            }
        }

        return CycleStatus(
            cycleDay = cycleDay,
            totalCycleDays = effectiveCycleLength,
            phase = phase,
            daysUntilNextPeriod = daysUntil.coerceAtLeast(0),
            isLate = isLate,
            lateDays = lateDays,
            nextPeriodDate = nextPeriodDate,
            ovulationDate = ovulationDate,
            fertileStart = fertileStart,
            fertileEnd = fertileEnd,
            conceptionChance = conceptionChance,
            dailyTipCategory = tipCategory,
            dailyTipTitle = tipTitle,
            dailyTipText = tipText
        )
    }

    fun isDateInFertileWindow(
        dateStr: String,
        lastPeriodDate: String,
        cycleLength: Int
    ): Boolean {
        if (lastPeriodDate.isBlank()) return false
        val ovulationDayNumber = (cycleLength - 14).coerceAtLeast(1)
        val ovulationDate = DateUtils.addDays(lastPeriodDate, ovulationDayNumber - 1)
        val fertileStart = DateUtils.addDays(ovulationDate, -5)
        val fertileEnd = DateUtils.addDays(ovulationDate, 1)
        return dateStr >= fertileStart && dateStr <= fertileEnd
    }

    fun isDateOvulationDay(
        dateStr: String,
        lastPeriodDate: String,
        cycleLength: Int
    ): Boolean {
        if (lastPeriodDate.isBlank()) return false
        val ovulationDayNumber = (cycleLength - 14).coerceAtLeast(1)
        val ovulationDate = DateUtils.addDays(lastPeriodDate, ovulationDayNumber - 1)
        return dateStr == ovulationDate
    }

    fun isDatePredictedPeriod(
        dateStr: String,
        lastPeriodDate: String,
        cycleLength: Int,
        periodLength: Int
    ): Boolean {
        if (lastPeriodDate.isBlank()) return false
        val nextPeriodStart = DateUtils.addDays(lastPeriodDate, cycleLength)
        val nextPeriodEnd = DateUtils.addDays(nextPeriodStart, periodLength - 1)
        return dateStr >= nextPeriodStart && dateStr <= nextPeriodEnd
    }

    private data class Tuple5<A, B, C, D, E>(
        val a: A, val b: B, val c: C, val d: D, val e: E
    )
}
