package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DeepPlum,
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = DarkPrimary,
    secondary = DarkSecondary,
    onSecondary = DeepPlum,
    tertiary = DarkDeepPlum,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkSurfaceVariant,
    outlineVariant = Color(0xFF4A3444)
)

private val LightColorScheme = lightColorScheme(
    primary = BlushPrimary,
    onPrimary = Color.White,
    primaryContainer = BlushLight,
    onPrimaryContainer = DeepPlum,
    secondary = LavenderAccent,
    onSecondary = Color.White,
    secondaryContainer = LavenderLight,
    onSecondaryContainer = DeepPlum,
    tertiary = DeepPlum,
    onTertiary = Color.White,
    background = CreamBackground,
    onBackground = TextPrimary,
    surface = CreamSurface,
    onSurface = TextPrimary,
    surfaceVariant = CreamSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BlushBorder,
    outlineVariant = Color(0xFFF2DEE4)
)

@Composable
fun BloomTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = BloomTypography,
        content = content
    )
}
