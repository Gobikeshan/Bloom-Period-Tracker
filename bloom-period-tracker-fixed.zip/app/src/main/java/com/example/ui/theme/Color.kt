package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bloom Theme Palette - Warm Blush, Lavender, Cream & Deep Plum
val BlushPrimary = Color(0xFFE2738F)
val BlushLight = Color(0xFFFDE8EC)
val BlushBorder = Color(0xFFF9CCD5)

val LavenderAccent = Color(0xFFA58BC7)
val LavenderLight = Color(0xFFF3EEFC)

val DeepPlum = Color(0xFF4A1A2C)
val DeepPlumLight = Color(0xFF752F48)

val CreamBackground = Color(0xFFFFF9F6)
val CreamSurface = Color(0xFFFFFFFF)
val CreamSurfaceVariant = Color(0xFFFFF1F3)

// Cycle Phase Semantic Colors
val PhasePeriod = Color(0xFFDE5274)
val PhasePeriodBg = Color(0xFFFEE8EE)

val PhaseFollicular = Color(0xFF947CB0)
val PhaseFollicularBg = Color(0xFFF3EDFA)

val PhaseOvulation = Color(0xFFE87A5D)
val PhaseOvulationBg = Color(0xFFFEEDEA)

val PhaseLuteal = Color(0xFFD98A44)
val PhaseLutealBg = Color(0xFFFEF4E8)

val FertileHighlight = Color(0xFFF5A3B7)

// Text Colors
val TextPrimary = Color(0xFF351722)
val TextSecondary = Color(0xFF7C636D)
val TextTertiary = Color(0xFFA6909A)

// Dark Theme Colors
val DarkBackground = Color(0xFF1B1017)
val DarkSurface = Color(0xFF281923)
val DarkSurfaceVariant = Color(0xFF382332)
val DarkPrimary = Color(0xFFF29BB0)
val DarkSecondary = Color(0xFFC7B1E4)
val DarkDeepPlum = Color(0xFFF7D5DF)
val DarkTextPrimary = Color(0xFFFDF0F3)
val DarkTextSecondary = Color(0xFFCBB7C1)
val DarkTextTertiary = Color(0xFF96808C)
