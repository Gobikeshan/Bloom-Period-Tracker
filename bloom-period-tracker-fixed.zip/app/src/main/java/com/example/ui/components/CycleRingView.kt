package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CyclePhase
import com.example.model.CycleStatus
import com.example.ui.theme.DeepPlum
import com.example.ui.theme.PhaseFollicular
import com.example.ui.theme.PhaseLuteal
import com.example.ui.theme.PhaseOvulation
import com.example.ui.theme.PhasePeriod
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun CycleRingView(
    cycleStatus: CycleStatus,
    isDiscreetMode: Boolean = false,
    modifier: Modifier = Modifier,
    size: Dp = 250.dp
) {
    val totalDays = cycleStatus.totalCycleDays.coerceAtLeast(20).toFloat()
    val currentDay = cycleStatus.cycleDay.coerceAtMost(cycleStatus.totalCycleDays + 5).toFloat()

    val progress = (currentDay / totalDays).coerceIn(0.01f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
        label = "cycleProgress"
    )

    // Calculate angles for 4 phases:
    // 1. Period: day 1 to ~5
    val periodFraction = 5f / totalDays
    // 2. Follicular: day 6 to ovulation - 1 (~13)
    val follicularFraction = (totalDays - 14f - 5f).coerceAtLeast(4f) / totalDays
    // 3. Ovulation: ~3 days around ovulation
    val ovulationFraction = 3f / totalDays
    // 4. Luteal: remaining
    val lutealFraction = (1f - periodFraction - follicularFraction - ovulationFraction).coerceAtLeast(0.1f)

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 18.dp.toPx()
            val arcSize = Size(this.size.width - strokeWidth * 2, this.size.height - strokeWidth * 2)
            val topLeft = Offset(strokeWidth, strokeWidth)
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = (this.size.width - strokeWidth * 2) / 2f

            // Start angle from top (-90 degrees)
            var currentAngle = -90f
            val spacingAngle = 3f // small aesthetic gap between arcs

            // 1. Period Arc
            val periodAngle = (360f * periodFraction) - spacingAngle
            drawArc(
                color = PhasePeriod,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = periodAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentAngle += periodAngle + spacingAngle

            // 2. Follicular Arc
            val follicularAngle = (360f * follicularFraction) - spacingAngle
            drawArc(
                color = PhaseFollicular,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = follicularAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentAngle += follicularAngle + spacingAngle

            // 3. Ovulation Arc
            val ovulationAngle = (360f * ovulationFraction) - spacingAngle
            drawArc(
                color = PhaseOvulation,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = ovulationAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            currentAngle += ovulationAngle + spacingAngle

            // 4. Luteal Arc
            val lutealAngle = (360f - (currentAngle - (-90f))) - spacingAngle
            drawArc(
                color = PhaseLuteal,
                startAngle = currentAngle + spacingAngle / 2f,
                sweepAngle = lutealAngle.coerceAtLeast(5f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Current Day indicator position on the ring
            val indicatorAngleRad = Math.toRadians(((-90f) + (360f * animatedProgress)).toDouble())
            val markerX = center.x + radius * cos(indicatorAngleRad).toFloat()
            val markerY = center.y + radius * sin(indicatorAngleRad).toFloat()

            // Outer glow / halo
            drawCircle(
                color = Color.White.copy(alpha = 0.9f),
                radius = strokeWidth * 0.75f,
                center = Offset(markerX, markerY)
            )
            // Inner colored pin
            drawCircle(
                color = cycleStatus.phase.color,
                radius = strokeWidth * 0.45f,
                center = Offset(markerX, markerY)
            )
        }

        // Center Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            if (cycleStatus.isLate) {
                Text(
                    text = "Late by",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${cycleStatus.lateDays}d",
                    style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
                    color = PhasePeriod
                )
            } else {
                Text(
                    text = if (isDiscreetMode) "Tracking" else "Cycle",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Day ${cycleStatus.cycleDay}",
                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Phase chip badge
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = cycleStatus.phase.bgColor
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = cycleStatus.phase.iconEmoji,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text(
                        text = if (isDiscreetMode) "Phase ${cycleStatus.phase.ordinal + 1}" else cycleStatus.phase.title,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = cycleStatus.phase.color
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = when {
                    cycleStatus.isLate -> "Expected soon"
                    cycleStatus.daysUntilNextPeriod == 0 -> "Period may start today"
                    cycleStatus.daysUntilNextPeriod == 1 -> "Period in 1 day"
                    else -> "Next in ${cycleStatus.daysUntilNextPeriod} days"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}
