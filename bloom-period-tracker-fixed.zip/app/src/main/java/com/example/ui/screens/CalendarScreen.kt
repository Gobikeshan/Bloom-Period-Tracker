package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AllSymptoms
import com.example.model.DailyLog
import com.example.model.FlowLevel
import com.example.ui.BloomUiState
import com.example.ui.theme.BlushLight
import com.example.ui.theme.BlushPrimary
import com.example.ui.theme.DeepPlum
import com.example.ui.theme.FertileHighlight
import com.example.ui.theme.LavenderAccent
import com.example.ui.theme.LavenderLight
import com.example.ui.theme.PhaseFollicular
import com.example.ui.theme.PhaseOvulation
import com.example.ui.theme.PhasePeriod
import com.example.util.CycleCalculator
import com.example.util.DateUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    uiState: BloomUiState,
    onSelectDate: (String) -> Unit,
    onOpenLog: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val today = DateUtils.today()
    var currentYear by remember { mutableIntStateOf(DateUtils.getYear(today)) }
    var currentMonth by remember { mutableIntStateOf(DateUtils.getMonth(today)) }

    val daysInMonth = DateUtils.getDaysInMonth(currentYear, currentMonth)
    val firstDayOfWeek = DateUtils.getFirstDayOfWeek(currentYear, currentMonth)

    val selectedDate = uiState.selectedDate
    val selectedLog = uiState.selectedDateLog

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Cycle Calendar",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Your rhythm, past records, and future predictions.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Calendar Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Month Navigation Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if (currentMonth == 1) {
                                    currentMonth = 12
                                    currentYear--
                                } else {
                                    currentMonth--
                                }
                            },
                            modifier = Modifier.testTag("cal_prev_month")
                        ) {
                            Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                        }

                        Text(
                            text = DateUtils.formatMonthYear(currentYear, currentMonth),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        IconButton(
                            onClick = {
                                if (currentMonth == 12) {
                                    currentMonth = 1
                                    currentYear++
                                } else {
                                    currentMonth++
                                }
                            },
                            modifier = Modifier.testTag("cal_next_month")
                        ) {
                            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Next Month")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Weekday Labels
                    val weekdays = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        weekdays.forEach { dayName ->
                            Text(
                                text = dayName,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Days Grid
                    val totalSlots = firstDayOfWeek + daysInMonth
                    val rows = (totalSlots + 6) / 7

                    for (row in 0 until rows) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            for (col in 0..6) {
                                val slotIndex = row * 7 + col
                                val dayNum = slotIndex - firstDayOfWeek + 1

                                if (dayNum in 1..daysInMonth) {
                                    val dateStr = DateUtils.buildDate(currentYear, currentMonth, dayNum)
                                    val isToday = dateStr == today
                                    val isSelected = dateStr == selectedDate

                                    val log = uiState.dailyLogs[dateStr]
                                    val isPeriodLogged = log != null && (log.isPeriod || log.flow != FlowLevel.NONE)
                                    val isPredictedPeriod = CycleCalculator.isDatePredictedPeriod(
                                        dateStr,
                                        uiState.settings.lastPeriodDate,
                                        uiState.settings.averageCycleLength,
                                        uiState.settings.averagePeriodLength
                                    )
                                    val isOvulation = CycleCalculator.isDateOvulationDay(
                                        dateStr,
                                        uiState.settings.lastPeriodDate,
                                        uiState.settings.averageCycleLength
                                    )
                                    val isFertile = CycleCalculator.isDateInFertileWindow(
                                        dateStr,
                                        uiState.settings.lastPeriodDate,
                                        uiState.settings.averageCycleLength
                                    )

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .padding(2.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    isPeriodLogged -> PhasePeriod
                                                    isOvulation -> PhaseOvulation.copy(alpha = 0.25f)
                                                    isFertile -> FertileHighlight.copy(alpha = 0.35f)
                                                    isPredictedPeriod -> BlushLight
                                                    isSelected -> MaterialTheme.colorScheme.surfaceVariant
                                                    else -> Color.Transparent
                                                }
                                            )
                                            .then(
                                                if (isSelected) {
                                                    Modifier.border(2.dp, DeepPlum, CircleShape)
                                                } else if (isToday) {
                                                    Modifier.border(1.5.dp, BlushPrimary, CircleShape)
                                                } else if (isPredictedPeriod && !isPeriodLogged) {
                                                    Modifier.border(1.dp, PhasePeriod.copy(alpha = 0.5f), CircleShape)
                                                } else {
                                                    Modifier
                                                }
                                            )
                                            .clickable {
                                                onSelectDate(dateStr)
                                            }
                                            .testTag("cal_day_$dateStr"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = dayNum.toString(),
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = if (isToday || isSelected || isPeriodLogged) FontWeight.Bold else FontWeight.Normal
                                                ),
                                                color = when {
                                                    isPeriodLogged -> Color.White
                                                    isOvulation -> PhaseOvulation
                                                    isSelected -> DeepPlum
                                                    isToday -> BlushPrimary
                                                    else -> MaterialTheme.colorScheme.onSurface
                                                }
                                            )
                                            // Tiny dot indicator for symptoms or ovulation
                                            if (isOvulation) {
                                                Text(text = "✦", fontSize = 8.sp, color = PhaseOvulation)
                                            } else if (log != null && log.symptoms.isNotEmpty() && !isPeriodLogged) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(4.dp)
                                                        .clip(CircleShape)
                                                        .background(LavenderAccent)
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Spacer(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Legend
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            LegendItem(color = PhasePeriod, label = "Logged Period")
                            LegendItem(color = BlushLight, label = "Predicted Period", hasBorder = true)
                            LegendItem(color = FertileHighlight.copy(alpha = 0.6f), label = "Fertile Window")
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            LegendItem(color = PhaseOvulation, label = "Ovulation Day ✦")
                            LegendItem(color = Color.Transparent, label = "Today", hasBorder = true, borderColor = BlushPrimary)
                            LegendItem(color = Color.Transparent, label = "Selected", hasBorder = true, borderColor = DeepPlum)
                        }
                    }
                }
            }
        }

        // Selected Day Details Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = DateUtils.formatDisplay(selectedDate),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            val isSelectedToday = selectedDate == today
                            Text(
                                text = if (isSelectedToday) "Today" else "Selected Day",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { onOpenLog(selectedDate) },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BlushPrimary),
                            modifier = Modifier.testTag("log_selected_day_button")
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Log Day", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Logged Details
                    if (selectedLog.isPeriod || selectedLog.flow != FlowLevel.NONE || selectedLog.symptoms.isNotEmpty() || selectedLog.mood != null || selectedLog.notes.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            if (selectedLog.flow != FlowLevel.NONE) {
                                Surface(shape = RoundedCornerShape(10.dp), color = BlushLight) {
                                    Text(
                                        text = "${selectedLog.flow.icon} ${selectedLog.flow.label}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = DeepPlum,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                            if (selectedLog.mood != null) {
                                Surface(shape = RoundedCornerShape(10.dp), color = LavenderLight) {
                                    Text(
                                        text = "Mood: ${selectedLog.mood}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = DeepPlum,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                Text(
                                    text = "💧 ${selectedLog.waterGlasses} cups",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }

                        if (selectedLog.symptoms.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                selectedLog.symptoms.forEach { symId ->
                                    val item = AllSymptoms.find { it.id == symId }
                                    if (item != null) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = "${item.emoji} ${item.label}",
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (selectedLog.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "\"${selectedLog.notes}\"",
                                style = MaterialTheme.typography.bodyMedium.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = "No symptoms or flow logged yet for this date.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun LegendItem(
    color: Color,
    label: String,
    hasBorder: Boolean = false,
    borderColor: Color = PhasePeriod
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
                .then(
                    if (hasBorder) Modifier.border(1.dp, borderColor, CircleShape) else Modifier
                )
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
